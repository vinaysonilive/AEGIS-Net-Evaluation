# %% [markdown]
# # AEGIS-Net – Revision Experiments (E1–E8) — complete cell-by-cell code
# 
# **Paper:** AEGIS-Net, IJIES Paper ID 20266595 (Accept after Major Revision).
# **Reference notebook:** `hybrid-cnn-lstm-mha` (Step 4 = final model: Quantile + selective SMOTE(3000) + Focal loss).
# **Saved artifacts re-used (no re-training needed for E4/E6-zero-shot/E7/E8):**
# `best_model.keras`, `scaler.pkl`, `label_encoder.pkl` in `Step4_Quantile_SMOTE_FocalLoss/`
# (the cell `0.2` auto-locates them under `/kaggle/input`).
# 
# ### How to read the comments
# Every code cell starts with a line `# >>> SATISFIES:` listing the reviewer/editor comment IDs it answers.
# Reviewer-1 = R1-x, Reviewer-2 = R2-x, Editor = ED-x. The full map is in the table below (and re-printed by the last cell).
# 
# | ID | Comment (short) | Cells |
# |---|---|---|
# | R1-1 | Factorial isolation of SMOTE / focal loss / class weights / T_floor | 0.7, 1.1, 1.3 |
# | R1-2 | Auditable split; duplicates / leakage; file-level grouping | 0.3, 0.5, 0.7, 4.1, 4.2, 4.3, 4.4 |
# | R1-3 | Feature order, layer shapes, parameter counts, hyper-parameters | 0.4, 0.6, 0.7, 1.2, 2.1, 3.1, 3.2 |
# | R1-4 | Few-shot sample count (50/class vs 619 total) and K-sweep | 6.2, 6.3, 6.5 |
# | R1-5 | Definition and counts of 'minority' classes | 0.4, 0.5, 4.5, 6.1 |
# | R1-6 | Majority vs minority macro-F1 wording | 4.6 |
# | R1-7 | Recall vs accuracy; normalisation fitted on train split only | 0.5, 0.7, 1.1, 1.3, 4.1, 4.6 |
# | R1-8 | Latency specification (batch, warm-up, percentiles, preprocessing) | 0.2, 8.1, 8.2, 8.3, 8.4 |
# | R1-9 | Mapping quality; model-vs-feature shift; fill strategy | 6.1, 6.3, 6.4, 6.6, 6.7 |
# | R1-10 | XAI sample size, CIs, baselines, kernel sensitivity | 7.1, 7.2, 7.3, 7.4, 7.5 |
# | R1-11 | Code / artifact release | 0.1, 0.2, 0.3, 4.1, 9.1 |
# | R1-12 | Reproduced baselines (same split, same preprocessing) | 2.1, 4.2, 4.3, 5.1, 5.2, 5.3 |
# | R1-13 | Calibration / few-shot / evaluation disjointness | 4.4, 6.2 |
# | R2-1 | Novelty vs strong baselines (RF, XGBoost, Transformer, [8], [9]) | 0.6, 1.2, 2.1, 3.1, 4.2, 5.1, 5.2, 5.3 |
# | R2-2 | Zero-shot vs supervised + target-trained baseline | 6.2, 6.3, 6.4, 6.5 |
# | R2-3 | Multi-seed, paired, parameter-matched ablation with CIs | 0.4, 0.6, 0.7, 1.1, 1.2, 1.3, 3.1, 5.3, 6.4, 6.5 |
# | R2-4 | Per-class CIs; 34-class vs 8-category; false-alert cost | 0.4, 4.5, 4.6, 4.7, 6.8 |
# | R2-5 | Label coverage / harmonisation; results by mapping quality | 6.1, 6.4, 6.6, 6.8 |
# | R2-6 | XAI framing, stability, offline use | 7.2, 7.3, 7.4, 7.5 |
# | R2-7 | Edge-deployment claim: measurements | 0.2, 8.1, 8.2, 8.3, 8.4 |
# | ED | Editor: code release (README, seeds, hyper-parameters, weights), reproducibility | 0.1, 0.2, 0.3, 9.1 |
# 
# ### Discrepancies found between your notebook and the manuscript (please fix the TEXT or the CODE before submitting)
# 1. **Architecture text:** the notebook uses plain `Dropout` and `Bidirectional(LSTM(64, return_sequences=False))`
#    (last-state output, **no GlobalAveragePooling**, no SpatialDropout). Parameter count = 210,978, which matches the paper, so the layer description in the text must be corrected.
# 2. **Quantile fit set:** the notebook fits `QuantileTransformer` on the *whole* `train.csv` **before** the 80/20 split
#    (validation rows influence the quantiles). The paper says "fitted on the 64 % training split only". This was NOT re-tested (section 1 limitation text); section 2 trains the final configuration with the train-split-only fit so you can compare it with your M6 numbers.
# 3. **Split sizes:** notebook pre-SMOTE train = 4,393,576 rows (80 % of `train.csv`); the manuscript quotes 3,765,923 / 941,481 / 1,176,851. Cell 0.5 prints the real numbers.
# 4. **"Full fine-tune" in the IoMT unified notebook** loops over `few_shot_model.layers` while compiling `full_model`
#    (so it is effectively head-only). E6 re-runs "head-only" and "all-layers" correctly.
# 5. **619** = total few-shot training samples (K = 50 per class, classes with <50 pool samples contribute fewer) – the text should say "up to 50 per class (619 in total)".
# 6. **LIME background** in the notebook is `X_test_scaled[:2000]` (test data) – E7 uses training data.
# 7. **Missing target features are zero-filled *before* quantile scaling**, which is not a neutral value (it maps to the extreme of the source distribution). E6 compares fill strategies.
# 8. **DIAD feature derivation bug:** `ack/syn/fin/rst_count` were looked up under their ORIGINAL names after the columns had been renamed, so they were always 0.0 (cell 6.1 flag `DIAD_FIX_COUNT_FEATURES`).
# 9. Few-shot sampling uses `np.random.choice` **without a seed**; the evaluation split is passed as `validation_data` during few-shot training. E6 uses seeded draws and an untouched evaluation split.

# %% [markdown]
# ## 0. Setup, environment capture, utilities

# %% ---- cell 0.1 ----
# [Cell 0.1]  → answers: ED, R1-11
# >>> SATISFIES: R1-11, ED (code release: library versions, hardware, seeds are captured here)
# Run once per fresh Kaggle/Colab session.
# scikit-learn is NOT pinned here: 1.3.2 has no wheel for Python 3.11+/3.12 and fails to build on Kaggle. The notebook records whatever version is installed (cell 0.2).
%pip -q install imbalanced-learn lime shap xgboost lightgbm psutil

# %% ---- cell 0.2 ----
# [Cell 0.2]  → answers: ED, R1-11, R1-8, R2-7
# >>> SATISFIES: R1-11, ED-code-release (version capture) | R1-8, R2-7 (hardware description)
import os, gc, json, time, glob, hashlib, platform, subprocess, sys, random, warnings, itertools, math, copy, shutil, zipfile
from collections import OrderedDict
import numpy as np, pandas as pd, joblib, scipy, sklearn
import tensorflow as tf
warnings.filterwarnings("ignore")

SEEDS = [7, 42, 100, 512, 2026]            # R2-3: the five seeds quoted in the paper
ENV = {
    "python": sys.version.split()[0], "platform": platform.platform(),
    "tensorflow": tf.__version__, "numpy": np.__version__, "pandas": pd.__version__,
    "scikit_learn": sklearn.__version__, "scipy": scipy.__version__,
    "gpus": [g.name for g in tf.config.list_physical_devices("GPU")],
}
try:
    ENV["nvidia_smi"] = subprocess.check_output(
        ["nvidia-smi", "--query-gpu=name,driver_version,memory.total", "--format=csv,noheader"], text=True).strip()
except Exception:
    ENV["nvidia_smi"] = "n/a"
try:
    ENV["cpu"] = [l.split(":")[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")][0]
    ENV["cpu_cores"] = os.cpu_count()
except Exception:
    pass
print(json.dumps(ENV, indent=2))

# %% ---- cell 0.3 ----
# [Cell 0.3]  → answers: ED, R1-11, R1-2
# >>> SATISFIES: R1-11 / ED (all paths in one place; artifacts auto-located) | R1-2 (single source of truth for the split)
# EDIT ONLY THIS CELL when you move between Kaggle / Colab / local.
KAGGLE_IN = "/kaggle/input"
WORK = "/kaggle/working/AEGIS_Revision" if os.path.exists("/kaggle/working") else "./AEGIS_Revision"
for sub in ["runs", "tables", "figures", "xai", "latency", "release", "preds"]:
    os.makedirs(f"{WORK}/{sub}", exist_ok=True)

def _find(pattern, what):
    hits = glob.glob(f"{KAGGLE_IN}/**/{pattern}", recursive=True)
    if not hits:
        print(f"[WARN] {what} not found with pattern {pattern}; set the path manually.")
        return None
    return sorted(hits)[0]

TRAIN_PATH = _find("ciciot2023/train.csv", "CICIoT2023 train.csv")
TEST_PATH  = _find("ciciot2023/test.csv",  "CICIoT2023 test.csv")
IOMT_PATH  = _find("ciciomt2024/test_iomt.csv", "CICIoMT2024 csv")
DIAD_PATH  = _find("ciciotdiad2024/*.csv", "CIC IoT-DIAD 2024 csv")
_model_file = _find("Step4_Quantile_SMOTE_FocalLoss/best_model.keras", "saved final model")
ART_DIR = os.path.dirname(_model_file) if _model_file else None       # saved artifacts: best_model.keras, scaler.pkl, label_encoder.pkl
LABEL_COLUMN = "label"

# ---- training hyper-parameters (identical to the paper / reference notebook) --------------------
PROFILE = "FAST"                    # "FAST" = reduced-budget protocol (~3 GPU-hours in total); "FULL" = paper protocol (days)
BATCH_SIZE, EPOCHS, PATIENCE = 256, (5 if PROFILE == "FAST" else 15), (3 if PROFILE == "FAST" else 5)
TRAIN_FRAC = 0.25 if PROFILE == "FAST" else 1.0   # random fraction of the 64 % training split used by the RETRAINED models (baselines, order study)
LR, GAMMA, ALPHA = 1e-3, 2.0, 0.25
T_FLOOR = 3000                      # SMOTE floor
MINORITY_THRESHOLD = 5000           # R1-5: majority/minority split = test support N_c >= 5000
SPLIT_SEED = 42                     # notebook: shuffle(random_state=42) + train_test_split(random_state=42, stratify)
DETERMINISTIC = True                # tf op-determinism (slower; set False for speed tests)
TARGET_FLOAT64 = False             # False reproduces the manuscript's transfer numbers (float32 cast, as in the original pipeline); True = float64 re-run
QUICK = False                       # True = smoke test (5 % of train, 2 epochs) to validate the pipeline in minutes
if QUICK:
    EPOCHS = 2
SEEDS_RUN = [42] if PROFILE == "FAST" else SEEDS   # seeds used by every retrained model in this notebook
print("ART_DIR:", ART_DIR); print("WORK:", WORK)
with open(f"{WORK}/release/config.json", "w") as f:       # R1-11: hyper-parameters are written to disk for the code release
    json.dump(dict(SEEDS=SEEDS, BATCH_SIZE=BATCH_SIZE, EPOCHS=EPOCHS, PATIENCE=PATIENCE, LR=LR, GAMMA=GAMMA, ALPHA=ALPHA,
                   T_FLOOR=T_FLOOR, MINORITY_THRESHOLD=MINORITY_THRESHOLD, SPLIT_SEED=SPLIT_SEED, ENV=ENV), f, indent=2)

# %% ---- cell 0.4 ----
# [Cell 0.4]  → answers: R1-3, R1-5, R2-3, R2-4
# >>> SATISFIES: R2-3 (seed control), R1-3 (reproducibility), R1-5 (majority/minority wording), R2-4 (8-category taxonomy)
from tensorflow.keras import layers as L
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, f1_score, matthews_corrcoef,
                             precision_recall_fscore_support, confusion_matrix)
from scipy import stats

gpus = tf.config.list_physical_devices("GPU")
for g in gpus:
    try: tf.config.experimental.set_memory_growth(g, True)
    except RuntimeError: pass

def set_seed(seed):
    random.seed(seed); np.random.seed(seed)
    tf.keras.utils.set_random_seed(seed)
    if DETERMINISTIC:
        tf.config.experimental.enable_op_determinism()

@tf.keras.utils.register_keras_serializable(package="CustomLosses")
class CategoricalFocalLoss(tf.keras.losses.Loss):
    """Exactly the loss of the reference notebook (alpha is a scalar multiplier). Needed to load best_model.keras."""
    def __init__(self, gamma=2.0, alpha=0.25, name="categorical_focal_loss", **kw):
        super().__init__(name=name, **kw); self.gamma, self.alpha = gamma, alpha
    def call(self, y_true, y_pred):
        y_true = tf.cast(y_true, tf.float32)
        y_pred = tf.clip_by_value(y_pred, tf.keras.backend.epsilon(), 1.0 - tf.keras.backend.epsilon())
        ce = -y_true * tf.math.log(y_pred)
        return tf.reduce_sum(self.alpha * tf.pow(1.0 - y_pred, self.gamma) * ce, axis=-1)
    def get_config(self):
        c = super().get_config(); c.update(gamma=self.gamma, alpha=self.alpha); return c

class SparseFocalLoss(tf.keras.losses.Loss):
    """Same maths as CategoricalFocalLoss but takes integer labels (saves 600 MB of one-hot memory). gamma=0 -> alpha*CE."""
    def __init__(self, gamma=2.0, alpha=0.25, n_classes=34, name="sparse_focal", **kw):
        super().__init__(name=name, **kw); self.gamma, self.alpha, self.n = gamma, alpha, n_classes
    def call(self, y_true, y_pred):
        y = tf.one_hot(tf.cast(tf.reshape(y_true, [-1]), tf.int32), self.n)
        p = tf.clip_by_value(y_pred, 1e-7, 1 - 1e-7)
        return tf.reduce_sum(self.alpha * tf.pow(1.0 - p, self.gamma) * (-y * tf.math.log(p)), axis=-1)

def load_saved_model(path=None):
    """R1-11: loads the shipped artifact; compile=False avoids the custom-loss deserialisation problem."""
    return tf.keras.models.load_model(path or f"{ART_DIR}/best_model.keras", compile=False,
                                      custom_objects={"CategoricalFocalLoss": CategoricalFocalLoss})

# ---- 8-category taxonomy (identical to the generalisation notebook) --------------------------------
MACRO_ORDER = ['Benign', 'BruteForce', 'DDoS', 'DoS', 'Mirai', 'Recon', 'Spoofing', 'Web']
FINE_TO_MACRO = {
 'BenignTraffic': 'Benign', 'DictionaryBruteForce': 'BruteForce',
 'DDoS-ACK_Fragmentation': 'DDoS', 'DDoS-HTTP_Flood': 'DDoS', 'DDoS-ICMP_Flood': 'DDoS',
 'DDoS-ICMP_Fragmentation': 'DDoS', 'DDoS-PSHACK_Flood': 'DDoS', 'DDoS-RSTFINFlood': 'DDoS',
 'DDoS-SYN_Flood': 'DDoS', 'DDoS-SlowLoris': 'DDoS', 'DDoS-SynonymousIP_Flood': 'DDoS',
 'DDoS-TCP_Flood': 'DDoS', 'DDoS-UDP_Flood': 'DDoS', 'DDoS-UDP_Fragmentation': 'DDoS',
 'DoS-HTTP_Flood': 'DoS', 'DoS-SYN_Flood': 'DoS', 'DoS-TCP_Flood': 'DoS', 'DoS-UDP_Flood': 'DoS',
 'Mirai-greeth_flood': 'Mirai', 'Mirai-greip_flood': 'Mirai', 'Mirai-udpplain': 'Mirai',
 'Recon-HostDiscovery': 'Recon', 'Recon-OSScan': 'Recon', 'Recon-PingSweep': 'Recon',
 'Recon-PortScan': 'Recon', 'VulnerabilityScan': 'Recon', 'MITM-ArpSpoofing': 'Spoofing',
 'DNS_Spoofing': 'Spoofing', 'BrowserHijacking': 'Web', 'CommandInjection': 'Web',
 'SQLInjection': 'Web', 'Uploading_Attack': 'Web', 'XSS': 'Web', 'Backdoor_Malware': 'Web'}

_FM_LC = {k.lower(): v for k, v in FINE_TO_MACRO.items()}   # case-insensitive: dataset spells 'SqlInjection'
def macro_vector(classes):
    """maps fine-class index -> macro index (R2-4)."""
    return np.array([MACRO_ORDER.index(_FM_LC[c.lower()]) for c in classes])

# ---- metric helpers --------------------------------------------------------------------------------
def full_metrics(y_true, y_pred, n_classes, macro_map=None):
    """R1-5/R1-6/R1-7/R2-4: every number the paper quotes, computed from one place.
    macro_f1_major/minor use the TEST support N_c >= MINORITY_THRESHOLD as in the notebook ('16 minority classes')."""
    labels = np.arange(n_classes)
    cnt = np.bincount(y_true, minlength=n_classes)
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=labels, zero_division=0)
    maj, mino = (cnt >= MINORITY_THRESHOLD), (cnt < MINORITY_THRESHOLD) & (cnt > 0)
    out = dict(acc=accuracy_score(y_true, y_pred), bal_acc=balanced_accuracy_score(y_true, y_pred),
               macro_f1=f[cnt > 0].mean(), weighted_f1=f1_score(y_true, y_pred, average="weighted", zero_division=0),
               weighted_recall=(r * cnt).sum() / cnt.sum(),             # == accuracy (R1-7: explain in text)
               mcc=matthews_corrcoef(y_true, y_pred),
               macro_f1_major=f[maj].mean(), macro_f1_minor=f[mino].mean(),
               n_major=int(maj.sum()), n_minor=int(mino.sum()))
    if macro_map is not None:
        out["macro8_f1"] = f1_score(macro_map[y_true], macro_map[y_pred], average="macro", zero_division=0)
        out["macro8_acc"] = accuracy_score(macro_map[y_true], macro_map[y_pred])
    return {k: float(v) for k, v in out.items()}

def t_ci(x, level=0.95):
    """R2-3: mean and t-based CI across seeds (n=5, so no Wilcoxon)."""
    x = np.asarray(x, float); n = len(x)
    if n < 2: return float(x.mean()), np.nan, np.nan
    h = stats.t.ppf((1 + level) / 2, n - 1) * x.std(ddof=1) / np.sqrt(n)
    return float(x.mean()), float(x.mean() - h), float(x.mean() + h)

def paired_delta(df, metric, ref_tag, tag):
    """R2-3: paired seed-wise difference (tag - ref) with 95 % t-CI."""
    a = df[df.tag == tag].set_index("seed")[metric]; b = df[df.tag == ref_tag].set_index("seed")[metric]
    common = a.index.intersection(b.index)
    d = (a[common] - b[common]).values
    m, lo, hi = t_ci(d)
    return dict(tag=tag, ref=ref_tag, metric=metric, n=len(d), delta=m, ci_lo=lo, ci_hi=hi)

def collect(prefix=""):
    """reads every finished run json into one DataFrame."""
    rows = []
    for p in sorted(glob.glob(f"{WORK}/runs/{prefix}*.json")):
        rows.append(json.load(open(p)))
    return pd.DataFrame(rows)

def summarise(df, metrics=("macro_f1", "macro_f1_minor", "macro_f1_major", "mcc", "acc", "macro8_f1"), ref_tag=None):
    """mean ± CI table over seeds (+ paired delta vs ref_tag)."""
    out = []
    for tag, g in df.groupby("tag"):
        row = {"tag": tag, "n_seeds": g.seed.nunique(), "params": int(g.params.iloc[0]) if "params" in g else np.nan}
        for m in metrics:
            mu, lo, hi = t_ci(g[m].values)
            row[m] = f"{mu:.4f} [{lo:.4f},{hi:.4f}]"
        if ref_tag and tag != ref_tag and ref_tag in set(df.tag):
            d = paired_delta(df, "macro_f1", ref_tag, tag)
            row["Δmacro_f1 vs ref"] = f"{d['delta']:+.4f} [{d['ci_lo']:+.4f},{d['ci_hi']:+.4f}]"
        out.append(row)
    return pd.DataFrame(out)
print("utilities ready")

# %% ---- cell 0.5 ----
# [Cell 0.5]  → answers: R1-2, R1-5, R1-7
# >>> SATISFIES: R1-2 (auditable split: indices saved, class counts printed, split sizes reconciled with the manuscript),
#                R1-5 (minority definition counts), R1-7 (what the quantile transformer is fitted on)
# Loads the raw CICIoT2023 files EXACTLY like the reference notebook (shuffle(random_state=42) -> 80/20 stratified split) so that the
# split is identical to the one used for the saved model. Raw (unscaled) arrays are kept: every experiment chooses its own scaler.
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import QuantileTransformer, StandardScaler

label_encoder = joblib.load(f"{ART_DIR}/label_encoder.pkl")
saved_scaler  = joblib.load(f"{ART_DIR}/scaler.pkl")
CLASSES = list(label_encoder.classes_); NC = len(CLASSES)
MACRO_MAP = macro_vector(CLASSES)

train_df = pd.read_csv(TRAIN_PATH).sample(frac=1.0, random_state=SPLIT_SEED).reset_index(drop=True)
test_df  = pd.read_csv(TEST_PATH).sample(frac=1.0, random_state=SPLIT_SEED).reset_index(drop=True)
FEATURES = [c for c in train_df.columns if c != LABEL_COLUMN]
ND = len(FEATURES)
X_raw  = train_df[FEATURES].values.astype(np.float64); y_all = label_encoder.transform(train_df[LABEL_COLUMN].values).astype(np.int32)
Xte_raw = test_df[FEATURES].values.astype(np.float64); y_te   = label_encoder.transform(test_df[LABEL_COLUMN].values).astype(np.int32)
SRC_COL = [c for c in train_df.columns if c.lower() in ("source_file", "file", "filename", "pcap", "capture")]
del train_df, test_df; gc.collect()

idx_tr, idx_val = train_test_split(np.arange(len(y_all)), test_size=0.2, random_state=SPLIT_SEED, stratify=y_all)
np.savez_compressed(f"{WORK}/release/split_indices.npz", idx_train=idx_tr, idx_val=idx_val)   # R1-2/R1-11: publish this file
print(f"features = {ND}, classes = {NC}")
print(f"train.csv rows = {len(y_all):,} | train(pre-SMOTE) = {len(idx_tr):,} | val = {len(idx_val):,} | test.csv rows = {len(y_te):,}")
print("-> compare these numbers with Section 'Dataset and split' of the manuscript (it quotes 3,765,923 / 941,481 / 1,176,851).")

cnt_tr = np.bincount(y_all[idx_tr], minlength=NC); cnt_te = np.bincount(y_te, minlength=NC)
split_table = pd.DataFrame(dict(cls=CLASSES, macro=[MACRO_ORDER[i] for i in MACRO_MAP], n_train=cnt_tr, n_val=np.bincount(y_all[idx_val], minlength=NC),
                                n_test=cnt_te, smote_target=(cnt_tr < T_FLOOR), minority_by_test_support=(cnt_te < MINORITY_THRESHOLD)))
split_table.to_csv(f"{WORK}/tables/S8_split_class_counts.csv", index=False)
print(f"classes below T_floor (SMOTE targets): {int(split_table.smote_target.sum())} | majority (N_c>={MINORITY_THRESHOLD}): "
      f"{int((~split_table.minority_by_test_support).sum())} | minority: {int(split_table.minority_by_test_support.sum())}")
display(split_table) if "display" in globals() else print(split_table.to_string())

# %% ---- cell 0.6 ----
# [Cell 0.6]  → answers: R1-3, R2-1, R2-3
# >>> SATISFIES: R1-3 (exact layer shapes, parameter counts, hyper-parameters), R2-3 (ablation variants must be parameter-matched),
#                R2-1 (strong NN baselines are built from the same builder)
# One parametric builder for: full model, -attention, -BiLSTM, both removed, parameter-matched variants, masking (E6).
class RandomFeatureMask(L.Layer):
    """Training-time-only random masking of chosen feature columns (E6 'train-time masking' strategy; R1-9)."""
    def __init__(self, cols, p=0.5, **kw):
        super().__init__(**kw); self.cols = list(cols); self.p = p
        m = np.zeros(ND, np.float32); m[self.cols] = 1.0; self.m = tf.constant(m.reshape(1, ND, 1))
    def call(self, x, training=None):
        if not training: return x
        drop = tf.cast(tf.random.uniform([tf.shape(x)[0], 1, 1]) < self.p, tf.float32)
        return x * (1.0 - drop * self.m)
    def get_config(self):
        c = super().get_config(); c.update(cols=self.cols, p=self.p); return c

def build_model(n_feat=None, n_cls=None, attn=True, rnn="bilstm", lstm_units=64, dense=128, conv=(64, 128), heads=4, key_dim=32,
                mask_cols=None, mask_p=0.5, name="aegis"):
    """Reference architecture (paper Fig.): Conv64-Pool-Drop-Conv128-Pool-Drop-[MHA+Add+LN]-BiLSTM64-Drop-Dense128-Drop-Softmax.
    rnn: 'bilstm' (reference) | 'flatten' (replaces BiLSTM by Flatten -> Dense) | 'gap' (GlobalAveragePooling)."""
    n_feat, n_cls = n_feat or ND, n_cls or NC
    inp = L.Input((n_feat, 1)); x = inp
    if mask_cols is not None: x = RandomFeatureMask(mask_cols, mask_p)(x)
    x = L.Conv1D(conv[0], 3, activation="relu", padding="same")(x); x = L.MaxPooling1D(2)(x); x = L.Dropout(0.3)(x)
    x = L.Conv1D(conv[1], 3, activation="relu", padding="same")(x); x = L.MaxPooling1D(2)(x); x = L.Dropout(0.3)(x)
    if attn:
        a = L.MultiHeadAttention(num_heads=heads, key_dim=key_dim)(x, x); x = L.LayerNormalization()(L.Add()([x, a]))
    if rnn == "bilstm":
        x = L.Bidirectional(L.LSTM(lstm_units, return_sequences=False))(x); x = L.Dropout(0.3)(x)
    elif rnn == "flatten":
        x = L.Flatten()(x); x = L.Dropout(0.3)(x)
    else:
        x = L.GlobalAveragePooling1D()(x); x = L.Dropout(0.3)(x)
    x = L.Dense(dense, activation="relu")(x); x = L.Dropout(0.4)(x)
    return tf.keras.Model(inp, L.Dense(n_cls, activation="softmax")(x), name=name)

REF_PARAMS = build_model().count_params()
print("reference parameter count:", REF_PARAMS, "(paper: 210,978)")
assert REF_PARAMS == 210978, "architecture differs from the manuscript - check build_model()"

def match_params(target, key, lo, hi, **spec):
    """R2-3: grid-search the integer `key` (e.g. lstm_units / dense) so that params ~ target (parameter-matched ablation)."""
    best = min(range(lo, hi + 1), key=lambda v: abs(build_model(**{**spec, key: v}).count_params() - target))
    m = build_model(**{**spec, key: best}); return best, m.count_params()

def layer_shape_table(model):
    """R1-3: per-layer output shapes and parameters (supplementary table)."""
    return pd.DataFrame([dict(layer=l.name, type=l.__class__.__name__, output_shape=str(l.output.shape), params=l.count_params()) for l in model.layers])
shape_tab = layer_shape_table(build_model()); shape_tab.to_csv(f"{WORK}/tables/S_layer_shapes_params.csv", index=False)
print(shape_tab.to_string(index=False))

# %% ---- cell 0.7 ----
# [Cell 0.7]  → answers: R1-1, R1-2, R1-3, R1-7, R2-3
# >>> SATISFIES: R1-1 (loss / class-weight / SMOTE switches), R1-7 (quantile fitted on the 64 % training split only), R2-3 (seeded, resumable runs),
#                R1-3 (feature order permutation hook), R1-2 (validation set is never SMOTE-d)
# Scaling, SMOTE and training in ONE function. Every call writes runs/<tag>__s<seed>.json + preds/<tag>__s<seed>.npz and is SKIPPED if it exists,
# so the 40+ runs can be spread over several Kaggle sessions (re-run the loop cell and it continues).
from imblearn.over_sampling import SMOTE
_scaled_cache = {}
def get_scaled(kind):
    """kind: 'saved' (notebook scaler, fit on whole train.csv) | 'q_train' (Quantile fit on the 64 % split only, paper claim) | 'standard'."""
    if kind in _scaled_cache: return _scaled_cache[kind]
    if kind == "saved":
        sc = saved_scaler
    elif kind == "q_train":
        sc = QuantileTransformer(n_quantiles=1000, output_distribution="normal", subsample=100000, random_state=SPLIT_SEED).fit(X_raw[idx_tr])
    elif kind == "standard":
        sc = StandardScaler().fit(X_raw[idx_tr])
    else: raise ValueError(kind)
    if len(_scaled_cache) >= 2: _scaled_cache.pop(next(iter(_scaled_cache)))        # keep RAM bounded
    out = (sc, sc.transform(X_raw).astype("float32"), sc.transform(Xte_raw).astype("float32"))
    _scaled_cache[kind] = out; return out

def log_class_weights(y):
    """Eq. 18-19 of the paper / notebook Step 2: W_c = ln(1 + N/(N_c+1)), normalised to mean 1."""
    cls, c = np.unique(y, return_counts=True)
    w = np.log(1.0 + len(y) / (c + 1.0)); w = w / w.mean()
    full = np.ones(NC, np.float32); full[cls] = w; return full

def smote_train(Xtr, ytr, floor, seed):
    """Selective SMOTE: only classes with N_c < floor are raised to `floor` (train split only)."""
    cnt = pd.Series(ytr).value_counts()
    strat = {int(c): int(floor) for c, n in cnt.items() if n < floor}
    if not strat: return Xtr, ytr, 0
    k = min(5, max(1, int(min(cnt[c] for c in strat)) - 1))
    Xf, yf = SMOTE(sampling_strategy=strat, random_state=seed, k_neighbors=k).fit_resample(Xtr, ytr)
    return Xf, yf, len(yf) - len(ytr)

def compile_for(model, loss, gamma=GAMMA, alpha=ALPHA, lr=LR):
    L_ = tf.keras.losses.SparseCategoricalCrossentropy() if loss == "ce" else SparseFocalLoss(gamma, alpha, NC)
    model.compile(optimizer=tf.keras.optimizers.Adam(lr), loss=L_, metrics=["sparse_categorical_accuracy"])
    return model

# identical configurations are trained once and re-used under several tags (saves ~25 GPU-hours)
ALIAS_OF = {"E2_full": "E1_focal_nocw_smote", "E1s_quantile_trainsplit": "E1_focal_nocw_smote", "E1t_floor3000": "E1_focal_nocw_smote",
            "E1g_gamma2": "E1_focal_nocw_smote", "E3_orig": "E1_focal_nocw_smote", "E1t_floor0": "E1_focal_nocw_nosmote"}
def _try_alias(tag, seed):
    src = ALIAS_OF.get(tag)
    if not src: return None
    sj = f"{WORK}/runs/{src}__s{seed}.json"
    if not os.path.exists(sj): return None
    m = json.load(open(sj)); m["tag"] = tag; json.dump(m, open(f"{WORK}/runs/{tag}__s{seed}.json", "w"))
    for ext in ["preds/%s__s%d.npz", "runs/%s__s%d.weights.h5"]:
        s_ = f"{WORK}/" + ext % (src, seed)
        if os.path.exists(s_): shutil.copy(s_, f"{WORK}/" + ext % (tag, seed))
    return m

def run_experiment(tag, seed, *, loss="focal", cw=False, floor=T_FLOOR, scaler_kind="q_train", gamma=GAMMA, alpha=ALPHA,
                   builder=None, perm=None, epochs=None, train_frac=None, mask_cols=None, extra=None, keep_weights=False):
    """Trains one configuration with one seed and stores metrics+predictions.
    loss: 'ce'|'focal'; cw: log-smoothed class weights on/off; floor: SMOTE T_floor (None/0 = off);
    builder: callable(n_feat, n_cls) -> keras model (default = reference architecture); perm: feature-order permutation (E3)."""
    jpath, ppath = f"{WORK}/runs/{tag}__s{seed}.json", f"{WORK}/preds/{tag}__s{seed}.npz"
    if os.path.exists(jpath): return json.load(open(jpath))
    a = _try_alias(tag, seed)
    if a is not None: return a
    set_seed(seed); tf.keras.backend.clear_session(); t0 = time.time()
    sc, Xall, Xte = get_scaled(scaler_kind)
    Xtr, ytr, Xval, yval = Xall[idx_tr], y_all[idx_tr], Xall[idx_val], y_all[idx_val]
    frac = train_frac if train_frac is not None else (0.05 if QUICK else TRAIN_FRAC)
    if frac < 1.0:
        keep = np.random.RandomState(seed).rand(len(ytr)) < frac; Xtr, ytr = Xtr[keep], ytr[keep]
    n_syn = 0
    if floor:
        Xtr, ytr, n_syn = smote_train(Xtr, ytr, floor, seed)
    if perm is not None: Xtr, Xval, Xte_ = Xtr[:, perm], Xval[:, perm], Xte[:, perm]
    else: Xte_ = Xte
    Xtr, Xval, Xte_ = Xtr[..., None], Xval[..., None], Xte_[..., None]
    sw = log_class_weights(ytr)[ytr] if cw else None
    model = (builder or (lambda nf, nc: build_model(nf, nc, mask_cols=mask_cols)))(ND, NC)
    compile_for(model, loss, gamma, alpha)
    cb = [tf.keras.callbacks.EarlyStopping(monitor="val_loss", patience=PATIENCE, restore_best_weights=True)]
    hist = model.fit(Xtr, ytr, sample_weight=sw, validation_data=(Xval, yval), epochs=epochs or EPOCHS, batch_size=BATCH_SIZE,
                     callbacks=cb, verbose=2)
    proba = model.predict(Xte_, batch_size=1024, verbose=0); yp = proba.argmax(1)
    m = full_metrics(y_te, yp, NC, MACRO_MAP)
    m.update(tag=tag, seed=seed, params=int(model.count_params()), loss=loss, cw=bool(cw), floor=int(floor or 0), scaler=scaler_kind,
             gamma=gamma, n_train=int(len(ytr)), n_synthetic=int(n_syn), epochs_run=len(hist.history["loss"]),
             best_val_loss=float(min(hist.history["val_loss"])), minutes=round((time.time() - t0) / 60, 2), **(extra or {}))
    np.savez_compressed(ppath, y_true=y_te, y_pred=yp.astype(np.int16), proba=proba.astype(np.float16))
    if keep_weights: model.save_weights(f"{WORK}/runs/{tag}__s{seed}.weights.h5")
    json.dump(m, open(jpath, "w"))
    print(f"[{tag} s{seed}] macroF1={m['macro_f1']:.4f} minorF1={m['macro_f1_minor']:.4f} acc={m['acc']:.4f} ({m['minutes']} min)")
    del Xtr, Xval, model; gc.collect(); return m
print("run_experiment ready. QUICK =", QUICK)

# %% [markdown]
# ## 1. E1 + E2 – imbalance factorial and component ablation: **imported from your existing 5-seed runs (no retraining)**
# Table N2 of the revised manuscript is built from your measured M1–M14 values. Experiments that were NOT re-run (Quantile-scaled counterparts of M1–M5/M7/M8,
# T_floor sweep, γ sweep, quantile-fit-on-train-split-only check) are stated as limitations (wording in the last cell of this section).

# %% ---- cell 1.1 ----
# [Cell 1.1]  → answers: R1-1, R1-7, R2-3
# >>> SATISFIES: R1-1 (factorial: loss × class weights × SMOTE, plus scaler and architecture rows, Table N2), R2-3 (multi-seed ablation with CIs; see note on paired vs unpaired),
#                R1-7 (the scaler of every row is stated explicitly)
# Values copied from your results table (mean ± SD over the 5 seeds 7, 42, 100, 512, 2026). If you have PER-SEED values put them in PER_SEED_CSV
# (columns: exp_id, seed, acc, weighted_f1, macro_f1, majority_f1, minority_f1) and the cell switches to true PAIRED differences.
M_TABLE = """
M1;Cross-Entropy;None;Off;StandardScaler (Baseline);97.93 ± 0.12;0.978 ± 0.0011;0.6432 ± 0.0082;0.9590 ± 0.0015;0.2966 ± 0.0071
M2;Cross-Entropy;None;On;StandardScaler (Isolates SMOTE);97.88 ± 0.13;0.9780 ± 0.0012;0.6708 ± 0.0079;0.9587 ± 0.0016;0.3549 ± 0.0070
M3;Cross-Entropy;Log-Weights;Off;StandardScaler (Isolates Weights);98.15 ± 0.10;0.9803 ± 0.0009;0.6465 ± 0.0075;0.9583 ± 0.0013;0.3037 ± 0.0065
M4;Cross-Entropy;Log-Weights;On;StandardScaler (CE + Weights + SMOTE);98.14 ± 0.11;0.9801 ± 0.0010;0.6812 ± 0.0074;0.9589 ± 0.0014;0.3701 ± 0.0068
M5;Focal Loss;None;Off;StandardScaler (Isolates Focal Loss);97.44 ± 0.15;0.9727 ± 0.0014;0.6340 ± 0.0090;0.9389 ± 0.0021;0.2998 ± 0.0080
M6;Focal Loss;None;On;Quantile-Transformer (Proposed Final);99.08 ± 0.02;0.9900 ± 0.0003;0.7481 ± 0.0060;0.9824 ± 0.0012;0.4905 ± 0.0128
M7;Focal Loss;Log-Weights;Off;StandardScaler;97.82 ± 0.13;0.9768 ± 0.0012;0.6590 ± 0.0081;0.9482 ± 0.0017;0.3204 ± 0.0072
M8;Focal Loss;Log-Weights;On;StandardScaler;98.42 ± 0.11;0.9830 ± 0.0008;0.6954 ± 0.0070;0.9631 ± 0.0012;0.3850 ± 0.0061
M9;Focal Loss;None;On;StandardScaler (Focal + SMOTE only);98.30 ± 0.12;0.9818 ± 0.0010;0.7010 ± 0.0072;0.9650 ± 0.0013;0.3920 ± 0.0064
M10;Focal Loss;None;On;Quantile-Transformer (- Attention);96.43 ± 0.22;0.9578 ± 0.0020;0.6191 ± 0.0110;0.8970 ± 0.0032;0.3064 ± 0.0095
M11;Focal Loss;None;On;Quantile-Transformer (- BiLSTM);96.45 ± 0.20;0.9621 ± 0.0018;0.6276 ± 0.0102;0.9073 ± 0.0029;0.3128 ± 0.0088
M12;Focal Loss;None;On;Quantile-Transformer (- Attention, param-matched);96.10 ± 0.25;0.9540 ± 0.0022;0.6050 ± 0.0120;0.8890 ± 0.0035;0.2950 ± 0.0102
M13;Focal Loss;None;On;Quantile-Transformer (- BiLSTM, param-matched);96.20 ± 0.23;0.9552 ± 0.0021;0.6110 ± 0.0115;0.8920 ± 0.0033;0.3010 ± 0.0098
M14;Focal Loss;None;On;Quantile-Transformer (Param-matched MLP, flat 46);95.12 ± 0.30;0.9440 ± 0.0029;0.5820 ± 0.0140;0.8750 ± 0.0041;0.2780 ± 0.0120
"""
N_SEEDS_M = 5                      # seeds behind each mean ± SD
PER_SEED_CSV = None                # e.g. "/kaggle/input/.../per_seed_ablation.csv"  -> enables paired deltas
METRICS_M = ["acc", "weighted_f1", "macro_f1", "majority_f1", "minority_f1"]
rows = []
for ln in M_TABLE.strip().splitlines():
    p = [x.strip() for x in ln.split(";")]
    r = dict(exp_id=p[0], loss=p[1], class_weights=p[2], smote=p[3], note=p[4])
    for m, v in zip(METRICS_M, p[5:]):
        mu, sd = [float(z) for z in v.split("±")]; r[m], r[m + "_sd"] = mu, sd
    rows.append(r)
MT = pd.DataFrame(rows).set_index("exp_id")

def welch_delta(a, b, metric, n=N_SEEDS_M, level=0.95):
    """UNPAIRED difference (a - b) with Welch t-interval computed from mean ± SD (n seeds each)."""
    d = MT.loc[a, metric] - MT.loc[b, metric]
    va, vb = MT.loc[a, metric + "_sd"] ** 2 / n, MT.loc[b, metric + "_sd"] ** 2 / n
    se = np.sqrt(va + vb); dfw = (va + vb) ** 2 / (va ** 2 / (n - 1) + vb ** 2 / (n - 1)); h = stats.t.ppf((1 + level) / 2, dfw) * se
    return d, d - h, d + h
def delta_table(ref="M6"):
    out = []
    for k in MT.index:
        if k == ref: continue
        row = dict(exp_id=k, config=f"{MT.loc[k,'loss']} | cw={MT.loc[k,'class_weights']} | SMOTE={MT.loc[k,'smote']} | {MT.loc[k,'note']}")
        for m in ["macro_f1", "minority_f1", "acc"]:
            d, lo, hi = welch_delta(k, ref, m); row[f"Δ{m} vs {ref}"] = f"{d:+.4f} [{lo:+.4f},{hi:+.4f}]" if m != "acc" else f"{d:+.2f} [{lo:+.2f},{hi:+.2f}]"
        out.append(row)
    return pd.DataFrame(out)
if PER_SEED_CSV and os.path.exists(PER_SEED_CSV):                                   # PAIRED version (preferred by R2-3)
    ps = pd.read_csv(PER_SEED_CSV); piv = {m: ps.pivot(index="seed", columns="exp_id", values=m) for m in ["macro_f1", "minority_f1", "acc"]}
    out = []
    for k in MT.index:
        if k == "M6": continue
        row = dict(exp_id=k)
        for m, pv in piv.items():
            mu, lo, hi = t_ci((pv[k] - pv["M6"]).values); row[f"Δ{m} vs M6 (paired)"] = f"{mu:+.4f} [{lo:+.4f},{hi:+.4f}]"
        out.append(row)
    N2 = pd.DataFrame(out); print("PAIRED differences (per-seed file used)")
else:
    N2 = delta_table("M6"); print("UNPAIRED (Welch) differences from mean ± SD – say 'unpaired' in the table caption (per-seed values were not available).")
full = MT.reset_index()[["exp_id", "loss", "class_weights", "smote", "note"] + METRICS_M + [m + "_sd" for m in METRICS_M]]
full.to_csv(f"{WORK}/tables/N2_ablation_from_existing_runs.csv", index=False); N2.to_csv(f"{WORK}/tables/N2_delta_vs_final.csv", index=False)
print(N2.to_string(index=False))
# clean factorial read-outs (same scaler within each comparison) – use these sentences in the text
print("\nSMOTE effect, CE/StandardScaler:     macro-F1 M2-M1 = %+.4f [%+.4f,%+.4f]" % welch_delta("M2", "M1", "macro_f1"))
print("Focal effect, no SMOTE/StandardScaler: macro-F1 M5-M1 = %+.4f [%+.4f,%+.4f]" % welch_delta("M5", "M1", "macro_f1"))
print("Class-weights, CE/no SMOTE:            macro-F1 M3-M1 = %+.4f [%+.4f,%+.4f]" % welch_delta("M3", "M1", "macro_f1"))
print("Scaler effect (focal+SMOTE):           macro-F1 M6-M9 = %+.4f [%+.4f,%+.4f]   <- Quantile vs Standard" % welch_delta("M6", "M9", "macro_f1"))
print("Attention (param-matched):             macro-F1 M6-M12= %+.4f [%+.4f,%+.4f]" % welch_delta("M6", "M12", "macro_f1"))
print("BiLSTM (param-matched):                macro-F1 M6-M13= %+.4f [%+.4f,%+.4f]" % welch_delta("M6", "M13", "macro_f1"))
print("MLP (param-matched):                   macro-F1 M6-M14= %+.4f [%+.4f,%+.4f]" % welch_delta("M6", "M14", "macro_f1"))

# %% ---- cell 1.2 ----
# [Cell 1.2]  → answers: R1-3, R2-1, R2-3
# >>> SATISFIES: R1-3 (parameter counts of all ablation variants, verifying that the 'param-matched' rows really are matched), R2-3 (parameter-matched ablation), R2-1
# Seconds to run, no training. Reports the parameter count of every ablation model so that Table N2 can carry a 'Params' column.
u_noattn, p_noattn = match_params(REF_PARAMS, "lstm_units", 16, 200, attn=False)
d_nolstm, p_nolstm = match_params(REF_PARAMS, "dense", 16, 400, attn=True, rnn="flatten")
def build_mlp(nf, nc, hidden=None):
    inp = L.Input((nf, 1)); x = L.Flatten()(inp)
    for h in hidden: x = L.Dense(h, activation="relu")(x); x = L.Dropout(0.3)(x)
    return tf.keras.Model(inp, L.Dense(nc, activation="softmax")(x), name="mlp")
h_mlp = min(range(32, 700), key=lambda h: abs(build_mlp(ND, NC, [h] * 3).count_params() - REF_PARAMS))
PC = pd.DataFrame([dict(row="M6 full", params=REF_PARAMS), dict(row="M10 -Attention (un-matched)", params=build_model(attn=False).count_params()),
                   dict(row="M11 -BiLSTM (GAP, un-matched)", params=build_model(rnn="gap").count_params()),
                   dict(row=f"M12 -Attention, matched (BiLSTM units={u_noattn})", params=p_noattn), dict(row=f"M13 -BiLSTM, matched (dense={d_nolstm})", params=p_nolstm),
                   dict(row=f"M14 MLP (3x{h_mlp})", params=build_mlp(ND, NC, [h_mlp] * 3).count_params())])
PC.to_csv(f"{WORK}/tables/N2_E2_param_counts.csv", index=False); print(PC.to_string(index=False))
print("-> compare these with the parameter counts of YOUR M10-M14 models; if they differ, fix the 'param-matched' wording or the table.")

# %% ---- cell 1.3 ----
# [Cell 1.3]  → answers: R1-1, R1-7, R2-3
# >>> SATISFIES: R1-1 / R2-3 / R1-7 – honest limitation wording for the experiments that were not re-run (paste into 'Limitations')
LIMITATIONS = """
Limitations of the imbalance and ablation study. The factorial in Table N2 varies loss, class weighting and SMOTE under StandardScaling (M1-M5, M7-M9), whereas the final model
uses the Quantile Transformer. Quantile-scaled counterparts of the other cells, a sweep over the SMOTE floor T_floor and the focal exponent gamma, and a re-fit of the quantile transform on the 64 %
training split alone were not re-run; the scaler effect is therefore isolated only for the focal-loss+SMOTE configuration (M9 vs M6). Differences in Table N2 are computed from mean +/- SD over five seeds
(unpaired Welch intervals), not from paired per-seed differences. The configuration T_floor = 3,000 and gamma = 2 follow the reference setting and were not tuned.
"""
open(f"{WORK}/release/LIMITATIONS_text.txt", "w").write(LIMITATIONS); print(LIMITATIONS)

# %% [markdown]
# ## 2. Reference runs of the final configuration (needed by E3 feature-order, E5 baselines and E6 masking)
# FAST profile: 1 run (≈ 7 min); FULL profile: 3 runs. These give per-seed AEGIS-Net results for the paired comparisons in Table N4 and the saved weights used by the E3 test-time control.
# If you skip them, the E3/E5 cells that read `E1_focal_nocw_smote` will have nothing to compare against.

# %% ---- cell 2.1 ----
# [Cell 2.1]  → answers: R1-12, R1-3, R2-1
# >>> SATISFIES: R1-12 / R2-1 (AEGIS-Net must be trained in the same pipeline, same seeds, as the reproduced baselines for paired differences), R1-3 (weights kept for the order-control)
FINAL_TAG = "E1_focal_nocw_smote"
SEEDS_REF = SEEDS_RUN
for seed in SEEDS_REF:
    run_experiment(FINAL_TAG, seed, loss="focal", cw=False, floor=T_FLOOR, keep_weights=True)
REF = collect(FINAL_TAG); print(summarise(REF).to_string(index=False))
print("compare with your M6 row: macro-F1 0.7481 ± 0.0060. A gap > 0.01 means the train-split-only quantile fit (this pipeline) differs from the saved-scaler pipeline of M6 – report both.")

# %% [markdown]
# ## 3. E3 – Sensitivity to feature order (the CNN/attention/BiLSTM treat the 46 features as a sequence)

# %% ---- cell 3.1 ----
# [Cell 3.1]  → answers: R1-3, R2-1, R2-3
# >>> SATISFIES: R1-3 (feature order is arbitrary – does it matter?), R2-3 (multi-seed), R2-1 (CNN-on-tabular-data critique)
# Orders: original | reversed | 5 random permutations | correlation-clustered (hierarchical clustering of |Spearman| computed on TRAIN only).
from scipy.cluster.hierarchy import linkage, leaves_list
from scipy.spatial.distance import squareform
_, Xs_all, _ = get_scaled("q_train")
sub = Xs_all[idx_tr][np.random.RandomState(0).choice(len(idx_tr), 200000, replace=False)]
rho = np.abs(stats.spearmanr(sub, nan_policy="omit")[0]); rho = np.nan_to_num(rho, nan=0.0); np.fill_diagonal(rho, 1.0)
dist = 1.0 - (rho + rho.T) / 2; np.fill_diagonal(dist, 0.0)
ORD_CLUSTER = leaves_list(linkage(squareform(dist, checks=False), "average")).astype(int)
ORDERS = OrderedDict([("orig", np.arange(ND)), ("reversed", np.arange(ND)[::-1].copy()), ("clustered", ORD_CLUSTER)])
for r in range(1 if PROFILE == "FAST" else 5): ORDERS[f"random{r+1}"] = np.random.RandomState(1000 + r).permutation(ND)
pd.DataFrame({k: [FEATURES[i] for i in v] for k, v in ORDERS.items()}).to_csv(f"{WORK}/tables/S6_feature_orders.csv", index=False)   # published list of orders
del sub, Xs_all; gc.collect()
SEEDS_E3 = SEEDS_RUN
for seed in SEEDS_E3:
    for name, p in ORDERS.items():
        run_experiment(f"E3_{name}", seed, loss="focal", cw=False, floor=T_FLOOR, perm=p, keep_weights=(name == "orig"))
E3 = collect("E3_"); t = summarise(E3, ref_tag="E3_orig"); t.to_csv(f"{WORK}/tables/S9d_feature_order.csv", index=False); print(t.to_string(index=False))

# %% ---- cell 3.2 ----
# [Cell 3.2]  → answers: R1-3
# >>> SATISFIES: R1-3 (control experiment, NO training: if shuffling test-time feature order destroys accuracy the model does use positional structure)
# Evaluates the E3_orig model of each seed on test data whose columns are shuffled (5 shuffles). Uses saved weights from the loop above.
rows = []
_, _, Xte_s = get_scaled("q_train")
for seed in SEEDS_E3:
    wpath = f"{WORK}/runs/E3_orig__s{seed}.weights.h5"
    if not os.path.exists(wpath): continue
    m = build_model(); m.load_weights(wpath)
    base = full_metrics(y_te, m.predict(Xte_s[..., None], batch_size=2048, verbose=0).argmax(1), NC, MACRO_MAP)
    rows.append(dict(seed=seed, order="orig", macro_f1=base["macro_f1"], acc=base["acc"]))
    for r in range(5):
        p = np.random.RandomState(r).permutation(ND)
        mm = full_metrics(y_te, m.predict(Xte_s[:, p][..., None], batch_size=2048, verbose=0).argmax(1), NC, MACRO_MAP)
        rows.append(dict(seed=seed, order=f"testshuffle{r+1}", macro_f1=mm["macro_f1"], acc=mm["acc"]))
ctl = pd.DataFrame(rows); ctl.to_csv(f"{WORK}/tables/S9e_testtime_shuffle_control.csv", index=False)
print(ctl.groupby("order")[["macro_f1", "acc"]].agg(["mean", "std"]).round(4))

# %% [markdown]
# ## 4. E4 – Re-evaluation of the SAVED model / predictions (no training)
# Uses only `best_model.keras`, `scaler.pkl`, `label_encoder.pkl` from the artifact folder.

# %% ---- cell 4.1 ----
# [Cell 4.1]  → answers: R1-11, R1-2, R1-7
# >>> SATISFIES: R1-7 (reproduces the headline numbers from the shipped artifacts), R1-11 (artifact integrity: SHA-256 of every shipped file),
#                R1-2 (the same test order and scaler as the paper)
def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""): h.update(b)
    return h.hexdigest()
ART_HASH = {os.path.basename(p): sha256(p) for p in glob.glob(f"{ART_DIR}/*") if os.path.isfile(p) and p.split(".")[-1] in ("keras", "pkl", "csv")}
json.dump(ART_HASH, open(f"{WORK}/release/artifact_sha256.json", "w"), indent=2); print(json.dumps(ART_HASH, indent=1))

saved_model = load_saved_model()
Xte_saved = saved_scaler.transform(Xte_raw).astype("float32")
P_saved = saved_model.predict(Xte_saved[..., None], batch_size=2048, verbose=1); yp_saved = P_saved.argmax(1)
np.savez_compressed(f"{WORK}/preds/SAVED_model_test.npz", y_true=y_te, y_pred=yp_saved.astype(np.int16), proba=P_saved.astype(np.float16))
M_SAVED = full_metrics(y_te, yp_saved, NC, MACRO_MAP); print(json.dumps(M_SAVED, indent=1))
rep = glob.glob(f"{ART_DIR}/classification_report.csv")
if rep:
    r0 = pd.read_csv(rep[0], index_col=0); print("saved report macro-F1 row:\n", r0.loc[[i for i in r0.index if "macro" in str(i).lower()]])

# %% ---- cell 4.2 ----
# [Cell 4.2]  → answers: R1-12, R1-2, R2-1
# >>> SATISFIES: R1-2 (exact and near-duplicate flows between train/val/test = leakage audit), R1-12/R2-1 (de-duplicated scoring so that baselines are compared fairly)
# (a) exact duplicates by row hash on RAW features; (b) near-duplicates by nearest neighbour distance < 1e-3 in the scaled space on a random 20k test sample.
def row_hash(X):
    """64-bit hash of every raw feature vector (chunked to bound memory)."""
    return np.concatenate([pd.util.hash_pandas_object(pd.DataFrame(X[i:i + 500000]), index=False).values for i in range(0, len(X), 500000)])
h_train, h_val, h_test = row_hash(X_raw[idx_tr]), row_hash(X_raw[idx_val]), row_hash(Xte_raw)
s_train = set(h_train.tolist())
test_in_train = np.array([h in s_train for h in h_test]); val_in_train = np.array([h in s_train for h in h_val])
_, first_idx = np.unique(h_test, return_index=True); test_is_first = np.zeros(len(h_test), bool); test_is_first[first_idx] = True
dup_tab = pd.DataFrame([
    dict(check="test rows whose exact raw feature vector appears in train(64%)", n=int(test_in_train.sum()), pct=100 * test_in_train.mean()),
    dict(check="val rows whose exact vector appears in train(64%)", n=int(val_in_train.sum()), pct=100 * val_in_train.mean()),
    dict(check="test rows duplicated inside test (2nd+ occurrence)", n=int((~test_is_first).sum()), pct=100 * (~test_is_first).mean()),
    dict(check="distinct train hashes / train rows", n=len(s_train), pct=100 * len(s_train) / len(h_train))])
print(dup_tab.to_string(index=False))

# near duplicates (scaled space, sample); uses faiss if installed, otherwise sklearn on a 300k train sample
rs = np.random.RandomState(0); q = Xte_saved[rs.choice(len(Xte_saved), 20000, replace=False)]
_, Xs_all, _ = get_scaled("saved"); ref = Xs_all[idx_tr][rs.choice(len(idx_tr), 300000, replace=False)]; del Xs_all
from sklearn.neighbors import NearestNeighbors
nn = NearestNeighbors(n_neighbors=1, algorithm="auto", n_jobs=-1).fit(ref); dnn = nn.kneighbors(q)[0][:, 0]
dup_tab.loc[len(dup_tab)] = dict(check="test sample (20k) with NN distance<1e-3 to 300k train sample", n=int((dnn < 1e-3).sum()), pct=100 * (dnn < 1e-3).mean())
dup_tab.to_csv(f"{WORK}/tables/S8_duplicates_audit.csv", index=False)
del ref, q; gc.collect()
if SRC_COL: print("source-file column present:", SRC_COL, "-> group the split by file (see next cell)")
else: print("[INFO] no source-file column in train.csv/test.csv: a file-grouped split is NOT possible; state this limitation in the paper (R1-2) "
            "and rely on the official, capture-disjoint train.csv/test.csv partition.")

# %% ---- cell 4.3 ----
# [Cell 4.3]  → answers: R1-12, R1-2
# >>> SATISFIES: R1-2 (does performance survive removal of duplicated test rows?), R1-12 (de-duplicated numbers for all models)
mask_clean = (~test_in_train) & test_is_first
rows = []
for nm, mk in [("all test rows", np.ones(len(y_te), bool)), ("exclude rows seen in train", ~test_in_train), ("exclude train-seen AND test-internal duplicates", mask_clean)]:
    m = full_metrics(y_te[mk], yp_saved[mk], NC, MACRO_MAP); m.update(subset=nm, n=int(mk.sum())); rows.append(m)
dedup = pd.DataFrame(rows)[["subset", "n", "acc", "macro_f1", "macro_f1_minor", "macro_f1_major", "mcc", "macro8_f1"]]
dedup.to_csv(f"{WORK}/tables/S8_dedup_scoring.csv", index=False); print(dedup.round(4).to_string(index=False))
# optional file-grouped split (only if a file/capture column exists)
if SRC_COL:
    print("TODO-if-available: GroupShuffleSplit on", SRC_COL[0], "-> retrain with run_experiment(..) using the grouped indices (idx_tr/idx_val) and report.")

# %% ---- cell 4.4 ----
# [Cell 4.4]  → answers: R1-13, R1-2
# >>> SATISFIES: R1-13 (calibration / few-shot / evaluation sets are disjoint – generic assertion helper used again in cell 6.2),
#                R1-2 (train / val / test of the source dataset are disjoint by index)
def assert_disjoint(**sets):
    names = list(sets); ok = True
    for a, b in itertools.combinations(names, 2):
        inter = np.intersect1d(np.asarray(sets[a]), np.asarray(sets[b]))
        print(f"  |{a} ∩ {b}| = {len(inter)}"); ok &= (len(inter) == 0)
    assert ok, "sets overlap!"
    return True
assert_disjoint(train=idx_tr, val=idx_val)
print("train/val index sets are disjoint; test.csv is a separate file (disjoint by construction, see duplicate audit for content overlap).")

# %% ---- cell 4.5 ----
# [Cell 4.5]  → answers: R1-5, R2-4
# >>> SATISFIES: R2-4 (per-class precision/recall/F1 with 95 % CIs: stratified bootstrap + Clopper–Pearson for small support), R1-5 (n_c per class)
# Stratified bootstrap on the confusion matrix: each true-class row is resampled multinomially (keeps n_c fixed) -> 1,000 replicates.
cm = confusion_matrix(y_te, yp_saved, labels=np.arange(NC))
def prf_from_cm(c):
    tp = np.diag(c).astype(float); fp = c.sum(0) - tp; fn = c.sum(1) - tp
    p = np.divide(tp, tp + fp, out=np.zeros(NC), where=(tp + fp) > 0); r = np.divide(tp, tp + fn, out=np.zeros(NC), where=(tp + fn) > 0)
    f = np.divide(2 * p * r, p + r, out=np.zeros(NC), where=(p + r) > 0); return p, r, f
rng = np.random.default_rng(2026); B = 1000; boots = np.zeros((B, 3, NC))
probs = cm / np.maximum(cm.sum(1, keepdims=True), 1)
for b in range(B):
    cb = np.stack([rng.multinomial(cm[i].sum(), probs[i]) if cm[i].sum() else np.zeros(NC, int) for i in range(NC)])
    boots[b] = np.stack(prf_from_cm(cb))
lo, hi = np.percentile(boots, 2.5, axis=0), np.percentile(boots, 97.5, axis=0)
p0, r0, f0 = prf_from_cm(cm)
def clopper(k, n, a=0.05):
    if n == 0: return (np.nan, np.nan)
    return (stats.beta.ppf(a / 2, k, n - k + 1) if k > 0 else 0.0, stats.beta.ppf(1 - a / 2, k + 1, n - k) if k < n else 1.0)
cp = [clopper(int(cm[i, i]), int(cm[i].sum())) for i in range(NC)]
per_class = pd.DataFrame(dict(cls=CLASSES, macro=[MACRO_ORDER[i] for i in MACRO_MAP], n_test=cm.sum(1),
    precision=p0, p_lo=lo[0], p_hi=hi[0], recall=r0, r_lo=lo[1], r_hi=hi[1], recall_CP_lo=[c[0] for c in cp], recall_CP_hi=[c[1] for c in cp],
    f1=f0, f1_lo=lo[2], f1_hi=hi[2], minority=cm.sum(1) < MINORITY_THRESHOLD))
per_class.to_csv(f"{WORK}/tables/S5_per_class_CI.csv", index=False); print(per_class.round(3).to_string(index=False))
# CI for the macro-F1 numbers themselves (majority / minority / all)
mf = lambda f, msk: f[:, msk].mean(1)
cnt = cm.sum(1)
for nm, msk in [("macro-F1 all", cnt > 0), ("macro-F1 majority (N_c>=5000)", cnt >= MINORITY_THRESHOLD), ("macro-F1 minority (N_c<5000)", (cnt < MINORITY_THRESHOLD) & (cnt > 0))]:
    v = boots[:, 2, :][:, msk].mean(1); print(f"{nm}: {f0[msk].mean():.4f}  95% CI [{np.percentile(v, 2.5):.4f}, {np.percentile(v, 97.5):.4f}]  ({int(msk.sum())} classes)")

# %% ---- cell 4.6 ----
# [Cell 4.6]  → answers: R1-6, R1-7, R2-4
# >>> SATISFIES: R2-4 (34-class vs 8-category macro-F1 reported side by side), R1-6 (majority / minority wording), R1-7 (recall ≡ accuracy under weighted averaging)
m34, m8 = M_SAVED["macro_f1"], M_SAVED["macro8_f1"]
print(f"34-class macro-F1 = {m34:.4f} | 8-category macro-F1 = {m8:.4f} | accuracy = {M_SAVED['acc']:.4f} | weighted recall = {M_SAVED['weighted_recall']:.4f} "
      f"(identical to accuracy by definition) | balanced acc. = {M_SAVED['bal_acc']:.4f} | MCC = {M_SAVED['mcc']:.4f}")
print(f"majority macro-F1 ({M_SAVED['n_major']} classes, N_c>=5000) = {M_SAVED['macro_f1_major']:.4f} | minority macro-F1 ({M_SAVED['n_minor']} classes) = {M_SAVED['macro_f1_minor']:.4f}")
assert abs(M_SAVED["acc"] - M_SAVED["weighted_recall"]) < 1e-9
cm8 = confusion_matrix(MACRO_MAP[y_te], MACRO_MAP[yp_saved], labels=np.arange(8))
pd.DataFrame(cm8, index=MACRO_ORDER, columns=MACRO_ORDER).to_csv(f"{WORK}/tables/S5_confusion_8cat.csv")
# which fine-class confusions are *within* the same macro-category (benign for the analyst) vs across categories
same = (MACRO_MAP[:, None] == MACRO_MAP[None, :]); off = cm * (~np.eye(NC, dtype=bool))
print(f"errors inside the same macro-category: {off[same].sum():,} of {off.sum():,} ({100 * off[same].sum() / max(off.sum(), 1):.1f} %)")

# %% ---- cell 4.7 ----
# [Cell 4.7]  → answers: R2-4
# >>> SATISFIES: R2-4 (false-alert cost: attack-vs-benign TPR/FPR and alert precision at deployment prevalence), Table N1 of the revised paper
# alert precision = prev*TPR / (prev*TPR + (1-prev)*FPR). The benign class is detected from the label encoder.
BEN = CLASSES.index("BenignTraffic")
is_att = y_te != BEN; pred_att = yp_saved != BEN
tpr = (pred_att & is_att).sum() / is_att.sum(); fpr = (pred_att & ~is_att).sum() / (~is_att).sum()
# bootstrap CI over test flows
rng = np.random.default_rng(1); n = len(y_te); tb, fb = [], []
for _ in range(1000):
    ii = rng.integers(0, n, n); ia, pa = is_att[ii], pred_att[ii]
    tb.append((pa & ia).sum() / max(ia.sum(), 1)); fb.append((pa & ~ia).sum() / max((~ia).sum(), 1))
rows = [dict(prevalence="test set", TPR=tpr, FPR=fpr, test_attack_share=is_att.mean())]
for prev in [0.001, 0.01, 0.10]:
    pr = prev * tpr / (prev * tpr + (1 - prev) * fpr)
    pr_lo = prev * np.percentile(tb, 2.5) / (prev * np.percentile(tb, 2.5) + (1 - prev) * np.percentile(fb, 97.5))
    pr_hi = prev * np.percentile(tb, 97.5) / (prev * np.percentile(tb, 97.5) + (1 - prev) * np.percentile(fb, 2.5))
    rows.append(dict(prevalence=f"{prev:.1%}", TPR=tpr, FPR=fpr, alert_precision=pr, ci_lo=pr_lo, ci_hi=pr_hi,
                     false_alerts_per_1M_flows=(1 - prev) * fpr * 1e6))
N1 = pd.DataFrame(rows); N1.to_csv(f"{WORK}/tables/N1_alert_precision.csv", index=False)
print(f"TPR 95% CI [{np.percentile(tb, 2.5):.4f},{np.percentile(tb, 97.5):.4f}] | FPR 95% CI [{np.percentile(fb, 2.5):.5f},{np.percentile(fb, 97.5):.5f}]")
print(N1.round(5).to_string(index=False))

# %% [markdown]
# ## 5. E5 – Reproduced baselines (same split, same quantile preprocessing, same SMOTE, same seeds)

# %% ---- cell 5.1 ----
# [Cell 5.1]  → answers: R1-12, R2-1
# >>> SATISFIES: R1-12 (all baselines are re-trained by us, not copied from the literature), R2-1 (strong baselines: RF, XGBoost, LightGBM, MLP, CNN,
#                CNN-BiLSTM, attention-CNN-LSTM of [8], CNN-BiLSTM-attention of [9], tabular Transformer)
# Neural baselines that are NOT in E2 are defined here. Reference [8]/[9] architectures are re-implemented from their published description
# (conv front-end + recurrent layer + attention pooling); rename the tags if your reference numbers differ.
class AttnPool(L.Layer):
    """additive attention pooling over the time axis (Bahdanau style) -> one vector."""
    def build(self, s):
        self.w = L.Dense(64, activation="tanh"); self.v = L.Dense(1, use_bias=False); super().build(s)
    def call(self, x):
        a = tf.nn.softmax(self.v(self.w(x)), axis=1); return tf.reduce_sum(a * x, axis=1)

def build_ref8_attn_cnn_lstm(nf, nc):          # CNN -> LSTM (uni-directional) -> attention pooling -> softmax
    i = L.Input((nf, 1)); x = L.Conv1D(64, 3, padding="same", activation="relu")(i); x = L.MaxPooling1D(2)(x)
    x = L.Conv1D(128, 3, padding="same", activation="relu")(x); x = L.MaxPooling1D(2)(x)
    x = L.LSTM(96, return_sequences=True)(x); x = AttnPool()(x); x = L.Dropout(0.3)(x)
    return tf.keras.Model(i, L.Dense(nc, activation="softmax")(L.Dense(128, activation="relu")(x)), name="ref8")

def build_ref9_cnn_bilstm_attn(nf, nc):        # CNN -> BiLSTM (all steps) -> attention pooling -> softmax
    i = L.Input((nf, 1)); x = L.Conv1D(64, 3, padding="same", activation="relu")(i); x = L.MaxPooling1D(2)(x)
    x = L.Conv1D(128, 3, padding="same", activation="relu")(x); x = L.MaxPooling1D(2)(x)
    x = L.Bidirectional(L.LSTM(64, return_sequences=True))(x); x = AttnPool()(x); x = L.Dropout(0.3)(x)
    return tf.keras.Model(i, L.Dense(nc, activation="softmax")(L.Dense(128, activation="relu")(x)), name="ref9")

class FeatureTokenizer(L.Layer):
    """each scalar feature -> d-dim token (value*w_i + b_i) + CLS token (FT-Transformer style)."""
    def __init__(self, d=64, **kw): super().__init__(**kw); self.d = d
    def build(self, s):
        n = s[1]; self.w = self.add_weight(shape=(n, self.d), initializer="glorot_uniform"); self.b = self.add_weight(shape=(n, self.d), initializer="zeros")
        self.cls = self.add_weight(shape=(1, 1, self.d), initializer="glorot_uniform"); super().build(s)
    def call(self, x):
        t = x * self.w[None] + self.b[None]; c = tf.tile(self.cls, [tf.shape(x)[0], 1, 1]); return tf.concat([c, t], axis=1)

def build_tab_transformer(nf, nc, d=64, blocks=2, heads=4):
    i = L.Input((nf, 1)); x = FeatureTokenizer(d)(i)
    for _ in range(blocks):
        a = L.MultiHeadAttention(heads, d // heads)(L.LayerNormalization()(x), L.LayerNormalization()(x)); x = L.Add()([x, a])
        f = L.Dense(2 * d, activation="gelu")(L.LayerNormalization()(x)); f = L.Dense(d)(f); x = L.Add()([x, f])
    x = L.LayerNormalization()(x)[:, 0]; x = L.Dropout(0.3)(x)
    return tf.keras.Model(i, L.Dense(nc, activation="softmax")(L.Dense(128, activation="relu")(x)), name="tab_transformer")

E5_NN = OrderedDict([
    ("AEGIS-Net (final)",            ("E1_focal_nocw_smote", None)),                        # trained in section 2
    ("Attention-CNN-LSTM [8]",       ("E5_ref8", build_ref8_attn_cnn_lstm)),
    ("CNN-BiLSTM-Attention [9]",     ("E5_ref9", build_ref9_cnn_bilstm_attn)),
    ("Tabular Transformer",          ("E5_tabtransformer", build_tab_transformer)),
])
SEEDS_E5 = SEEDS_RUN                      # same seeds as the AEGIS reference runs
for seed in SEEDS_E5:
    for nm, (tag, b) in E5_NN.items():
        if b is not None:
            run_experiment(tag, seed, loss="focal", cw=False, floor=T_FLOOR, builder=b)
for nm, (tag, b) in E5_NN.items():
    if b is not None: print(nm, "params =", b(ND, NC).count_params())

# %% ---- cell 5.2 ----
# [Cell 5.2]  → answers: R1-12, R2-1
# >>> SATISFIES: R1-12, R2-1 (tree-based baselines: Random Forest 300 trees, XGBoost, LightGBM – trained on the SAME SMOTE-ed, quantile-scaled training split)
import xgboost as xgb, lightgbm as lgb
from sklearn.ensemble import RandomForestClassifier
def train_arrays(seed, floor=T_FLOOR, kind="q_train"):
    sc, Xall, Xte = get_scaled(kind)
    Xtr, ytr = Xall[idx_tr], y_all[idx_tr]
    if TRAIN_FRAC < 1.0:
        keep = np.random.RandomState(seed).rand(len(ytr)) < TRAIN_FRAC; Xtr, ytr = Xtr[keep], ytr[keep]     # same subsample rule as run_experiment
    if floor: Xtr, ytr, _ = smote_train(Xtr, ytr, floor, seed)
    return Xtr, ytr, Xall[idx_val], y_all[idx_val], Xte

def run_tree(tag, seed, kind):
    jpath = f"{WORK}/runs/{tag}__s{seed}.json"
    if os.path.exists(jpath): return
    set_seed(seed); t0 = time.time(); Xtr, ytr, Xval, yval, Xte = train_arrays(seed)
    if kind == "rf":
        # max_samples bounds RAM on a 30 GB Kaggle machine; set to None (full bootstrap) on a larger box
        clf = RandomForestClassifier(n_estimators=(100 if PROFILE == "FAST" else 300), n_jobs=-1, random_state=seed, max_samples=0.3, class_weight=None).fit(Xtr, ytr)
        proba = clf.predict_proba(Xte); cls_ = clf.classes_
    elif kind == "xgb":
        clf = xgb.XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, tree_method="hist",
                                device="cuda" if gpus else "cpu", random_state=seed, early_stopping_rounds=20, eval_metric="mlogloss")
        clf.fit(Xtr, ytr, eval_set=[(Xval, yval)], verbose=False); proba = clf.predict_proba(Xte); cls_ = clf.classes_
    else:
        clf = lgb.LGBMClassifier(n_estimators=300, num_leaves=63, learning_rate=0.1, subsample=0.8, colsample_bytree=0.8, random_state=seed, verbose=-1)
        clf.fit(Xtr, ytr, eval_set=[(Xval, yval)], callbacks=[lgb.early_stopping(20, verbose=False)]); proba = clf.predict_proba(Xte); cls_ = clf.classes_
    full = np.zeros((len(Xte), NC), np.float32); full[:, cls_] = proba; yp = full.argmax(1)
    m = full_metrics(y_te, yp, NC, MACRO_MAP); m.update(tag=tag, seed=seed, params=-1, minutes=round((time.time() - t0) / 60, 2))
    np.savez_compressed(f"{WORK}/preds/{tag}__s{seed}.npz", y_true=y_te, y_pred=yp.astype(np.int16), proba=full.astype(np.float16))
    json.dump(m, open(jpath, "w")); print(f"[{tag} s{seed}] macroF1={m['macro_f1']:.4f} ({m['minutes']} min)"); del clf, Xtr; gc.collect()

SEEDS_TREES = SEEDS_RUN
for seed in SEEDS_TREES:
    for tag, kind in [("E5_rf300", "rf"), ("E5_xgboost", "xgb"), ("E5_lightgbm", "lgb")]:
        run_tree(tag, seed, kind)

# %% ---- cell 5.3 ----
# [Cell 5.3]  → answers: R1-12, R2-1, R2-3
# >>> SATISFIES: R1-12, R2-1, R2-3 (final baseline table = Table N4: mean ± 95 % CI, paired Δ vs AEGIS-Net, plus de-duplicated scores from E4)
def boot_ci(tag, seed, B=300):
    """CI over TEST-SET sampling (stratified bootstrap of the confusion matrix) for one seed's predictions; used when only 1 seed was trained."""
    z = np.load(f"{WORK}/preds/{tag}__s{seed}.npz"); cm_ = confusion_matrix(z["y_true"], z["y_pred"].astype(int), labels=np.arange(NC)); pr_ = cm_ / np.maximum(cm_.sum(1, keepdims=True), 1)
    rng_ = np.random.default_rng(0); v = []
    for _ in range(B):
        cb_ = np.stack([rng_.multinomial(cm_[i].sum(), pr_[i]) if cm_[i].sum() else np.zeros(NC, int) for i in range(NC)])
        tp = np.diag(cb_).astype(float); p = np.divide(tp, cb_.sum(0), out=np.zeros(NC), where=cb_.sum(0) > 0); r = np.divide(tp, cb_.sum(1), out=np.zeros(NC), where=cb_.sum(1) > 0)
        f = np.divide(2 * p * r, p + r, out=np.zeros(NC), where=(p + r) > 0); v.append(f[cm_.sum(1) > 0].mean())
    return np.percentile(v, [2.5, 97.5])
names = {tag: nm for nm, (tag, _) in E5_NN.items()}; names.update({"E5_rf300": "Random Forest", "E5_xgboost": "XGBoost", "E5_lightgbm": "LightGBM"})
ALL = pd.concat([collect("E5_"), collect("E1_focal_nocw_smote")], ignore_index=True); ALL["model"] = ALL.tag.map(names)
res = ALL.groupby("model")[["macro_f1", "macro_f1_minor", "macro_f1_major", "mcc", "macro8_f1", "acc"]].mean().reset_index()
tags_ = {v: k for k, v in names.items()}
res["macro_f1_95CI_testbootstrap"] = [str(boot_ci(tags_[m], SEEDS_RUN[0]).round(4)) for m in res.model]
def dedup_f1(tag):
    z = np.load(f"{WORK}/preds/{tag}__s{SEEDS_RUN[0]}.npz"); return round(full_metrics(z["y_true"][mask_clean], z["y_pred"][mask_clean].astype(int), NC, MACRO_MAP)["macro_f1"], 4)
res["macro_f1_dedup"] = [dedup_f1(tags_[m]) for m in res.model]
imp = pd.DataFrame([dict(model="MLP, param-matched (M14, 5 seeds, full protocol)", macro_f1=MT.loc["M14", "macro_f1"], macro_f1_minor=MT.loc["M14", "minority_f1"]),
                    dict(model="CNN-BiLSTM no attention, param-matched (M12, 5 seeds, full protocol)", macro_f1=MT.loc["M12", "macro_f1"], macro_f1_minor=MT.loc["M12", "minority_f1"])])
N4 = pd.concat([res, imp], ignore_index=True).sort_values("macro_f1", ascending=False); N4.to_csv(f"{WORK}/tables/N4_baselines.csv", index=False)
print(f"Reduced-budget protocol: {TRAIN_FRAC:.0%} of the training split, {EPOCHS} epochs, seed {SEEDS_RUN}. AEGIS-Net is retrained under the SAME protocol, so the comparison is fair; "
      "absolute values are lower than the full-protocol numbers of Table N2 and must be labelled as such.")
print(N4.round(4).to_string(index=False))

# %% [markdown]
# ## 6. E6 – Cross-dataset transfer study (CICIoMT2024 and CIC IoT-DIAD 2024)
# Re-uses the **saved** `best_model.keras` + `scaler.pkl` (zero-shot needs no training). Fine-tuning always starts from the saved weights.

# %% ---- cell 6.1 ----
# [Cell 6.1]  → answers: R1-5, R1-9, R2-5
# >>> SATISFIES: R2-5 (label coverage / harmonisation table), R1-9 (mapping quality of labels and features), R1-5 (what is "supported")
# Re-implements the target loaders of the generalisation notebook, but additionally (a) records which labels are mapped / dropped,
# (b) records feature provenance (direct / approximated / unmapped) and (c) keeps the *raw* matrix so that fill strategies can be compared (cell 6.6).
IOMT_LABEL_MAP = {'DDoS SYN': 'DDoS-SYN_Flood', 'DDoS TCP': 'DDoS-TCP_Flood', 'DDoS ICMP': 'DDoS-ICMP_Flood', 'DDoS UDP': 'DDoS-UDP_Flood',
                  'DoS SYN': 'DoS-SYN_Flood', 'DoS TCP': 'DoS-TCP_Flood', 'DoS UDP': 'DoS-UDP_Flood', 'Ping Sweep': 'Recon-PingSweep',
                  'Recon VulScan': 'VulnerabilityScan', 'OS Scan': 'Recon-OSScan', 'Port Scan': 'Recon-PortScan', 'ARP Spoofing': 'MITM-ArpSpoofing',
                  'benign': 'BenignTraffic', 'Benign': 'BenignTraffic'}
# EDIT if you disagree: 'exact' = same attack semantics, 'coarse' = related family only  (used for the by-mapping-quality table, R2-5)
LABEL_QUALITY = {k: ("coarse" if k in ("Recon VulScan", "ARP Spoofing") else "exact") for k in IOMT_LABEL_MAP}
DIAD_TO_MACRO = {'Benign': 'Benign', 'Reconnaissance': 'Recon', 'DoS': 'DoS', 'DDoS': 'DDoS', 'Mirai': 'Mirai', 'Spoofing': 'Spoofing', 'Web_Based': 'Web', 'Brute_Force': 'BruteForce'}
DIAD_FEATURE_MAP = {"flow duration": "flow_duration", "fwd header length": "Header_Length", "protocol": "Protocol Type", "flow packets/s": "Rate",
    "fwd packets/s": "Srate", "bwd packets/s": "Drate", "fin flag count": "fin_flag_number", "syn flag count": "syn_flag_number", "rst flag count": "rst_flag_number",
    "psh flag count": "psh_flag_number", "ack flag count": "ack_flag_number", "ece flag count": "ece_flag_number", "cwr flag count": "cwr_flag_number",
    "urg flag count": "urg_count", "packet length min": "Min", "packet length max": "Max", "packet length mean": "AVG", "packet length std": "Std",
    "average packet size": "Tot size", "flow iat mean": "IAT", "total fwd packet": "Number", "packet length variance": "Variance", "total length of fwd packet": "Tot sum"}
DIAD_DERIVED = ["Duration", "ack_count", "syn_count", "fin_count", "rst_count", "TCP", "UDP", "ICMP", "Magnitue", "Radius", "Covariance", "Weight"]
# The generalisation notebook looked up the UN-renamed names ("ack flag count" ...) AFTER renaming them, so ack/syn/fin/rst_count were silently 0.0.
# False = reproduce the numbers in the manuscript (these 4 features count as 'unmapped'); True = fill them from the renamed flag columns (an improvement to report separately).
DIAD_FIX_COUNT_FEATURES = False

def _num(s): return pd.to_numeric(s, errors="coerce")
def load_iomt():
    df = pd.read_csv(IOMT_PATH); df[LABEL_COLUMN] = df[LABEL_COLUMN].astype(str).str.strip()
    cover = df[LABEL_COLUMN].value_counts().rename_axis("native_label").reset_index(name="n")
    cover["mapped_to"] = cover.native_label.map(IOMT_LABEL_MAP); cover["quality"] = cover.native_label.map(LABEL_QUALITY).fillna("UNMAPPED/dropped")
    df["_m"] = df[LABEL_COLUMN].map(IOMT_LABEL_MAP); df = df.dropna(subset=["_m"]); df = df[df["_m"].isin(CLASSES)]
    y = label_encoder.transform(df["_m"].values).astype(np.int32); native = df[LABEL_COLUMN].values
    feats = df.drop(columns=[LABEL_COLUMN, "_m"], errors="ignore")
    raw = feats.reindex(columns=FEATURES).apply(_num).values.astype(np.float64)               # NaN where the feature does not exist in the target
    fq = np.array(["direct" if f in feats.columns else "unmapped" for f in FEATURES])
    return dict(name="CICIoMT2024", raw=raw, y=y, native=native, space="fine", feat_quality=fq, cover=cover)

def load_diad():
    df = pd.read_csv(DIAD_PATH); lab = [c for c in df.columns if c.lower() in ("label", "class", "attack", "category", "target")][0]
    df[lab] = df[lab].astype(str).str.strip(); df["_macro"] = df[lab].map(DIAD_TO_MACRO)
    cover = df[lab].value_counts().rename_axis("native_label").reset_index(name="n"); cover["mapped_to"] = cover.native_label.map(DIAD_TO_MACRO)
    cover["quality"] = np.where(cover.mapped_to.isna(), "UNMAPPED/dropped", "coarse (8-category)")
    df = df.dropna(subset=["_macro"]); y = np.array([MACRO_ORDER.index(m) for m in df["_macro"]], np.int32); native = df[lab].values
    f = df.drop(columns=[lab, "_macro"], errors="ignore").replace({r",": ""}, regex=True).apply(_num).fillna(0.0).rename(columns=DIAD_FEATURE_MAP)
    g = lambda c: f[c] if c in f.columns else pd.Series(0.0, index=f.index)
    f["Duration"] = g("flow_duration")
    for c, src_ in [("ack_count", "ack_flag_number"), ("syn_count", "syn_flag_number"), ("fin_count", "fin_flag_number"), ("rst_count", "rst_flag_number")]:
        f[c] = g(src_) if DIAD_FIX_COUNT_FEATURES else 0.0
    pr = _num(g("Protocol Type")).fillna(0); f["TCP"], f["UDP"], f["ICMP"] = (pr == 6).astype(float), (pr == 17).astype(float), (pr == 1).astype(float)
    if "Tot sum" not in f.columns: f["Tot sum"] = g("AVG") * g("Number")
    f["Magnitue"] = np.sqrt(g("AVG") ** 2 + g("Variance")); f["Radius"] = g("Std"); f["Covariance"] = g("Variance"); f["Weight"] = g("Number")
    raw = f.reindex(columns=FEATURES).apply(_num).values.astype(np.float64)
    fq = np.array(["direct" if (c in DIAD_FEATURE_MAP.values()) else ("approximated" if (c in DIAD_DERIVED and (DIAD_FIX_COUNT_FEATURES or not c.endswith("_count") or c == "urg_count")) else "unmapped") for c in FEATURES])
    return dict(name="CIC-IoT-DIAD-2024", raw=raw, y=y, native=native, space="macro", feat_quality=fq, cover=cover)

TARGETS = {}
for fn, ok in [(load_iomt, IOMT_PATH), (load_diad, DIAD_PATH)]:
    if ok:
        t = fn(); TARGETS[t["name"]] = t
        t["cover"].to_csv(f"{WORK}/tables/S1_label_coverage_{t['name']}.csv", index=False)
        print(f"\n=== {t['name']}: {len(t['y']):,} usable flows ===")
        print(t["cover"].to_string(index=False))
        print("feature provenance:", pd.Series(t["feat_quality"]).value_counts().to_dict())
        n_sup = len(np.unique(t["y"])); print(f"classes with >=1 target sample: {n_sup} of {NC if t['space']=='fine' else 8} ({'34-class' if t['space']=='fine' else '8-category'} space)")

# %% ---- cell 6.2 ----
# [Cell 6.2]  → answers: R1-13, R1-4, R2-2
# >>> SATISFIES: R1-13 (calibration pool / few-shot subsets / evaluation set are DISJOINT – asserted), R1-4 (actual few-shot sample counts: why 619 and not 50×classes),
#                R2-2 (fixed 10 % pool / 90 % evaluation protocol shared by all regimes)
SRC_MEDIAN = np.nanmedian(X_raw[idx_tr].astype(np.float64), axis=0)
def finalize(raw, fill="zero_raw"):
    """R1-9: fill strategy for features that do not exist in the target. zero_raw = notebook behaviour (0 BEFORE quantile scaling);
    median_raw = source training median (maps to ~0 after the quantile transform = 'neutral')."""
    X = raw.copy(); miss = np.isnan(X)
    X = np.where(miss, 0.0 if fill == "zero_raw" else SRC_MEDIAN[None, :], X)
    X = np.clip(np.nan_to_num(X, nan=0.0, posinf=1e10, neginf=-1e10), -3.4e38, 3.4e38)
    return saved_scaler.transform(X.astype(np.float64 if TARGET_FLOAT64 else np.float32)).astype("float32")

for t in TARGETS.values():
    ok_cls = np.where(np.bincount(t["y"]) >= 2)[0]; keep = np.isin(t["y"], ok_cls)          # stratify needs >= 2 per class
    ii = np.where(keep)[0]
    pool, ev = train_test_split(ii, test_size=0.90, random_state=42, stratify=t["y"][ii])
    assert_disjoint(pool=pool, eval=ev)                                                    # R1-13
    t.update(pool=pool, eval=ev, X0=finalize(t["raw"], "zero_raw"))
    pool_cnt = np.bincount(t["y"][pool], minlength=NC if t["space"] == "fine" else 8)
    rows = [dict(K=K, total_samples=int(np.minimum(pool_cnt, K).sum()), classes_with_samples=int((pool_cnt > 0).sum()),
                 classes_with_fewer_than_K=int(((pool_cnt > 0) & (pool_cnt < K)).sum())) for K in [5, 10, 25, 50, 100]]
    t["fewshot_counts"] = pd.DataFrame(rows); t["fewshot_counts"].to_csv(f"{WORK}/tables/S10_fewshot_counts_{t['name']}.csv", index=False)
    print(f"\n{t['name']}: pool = {len(pool):,} | eval = {len(ev):,}\n", t["fewshot_counts"].to_string(index=False))
print("-> K=50 gives the '619' of the manuscript only if 619 = sum(min(pool_count_c, 50)); the table above shows the exact figure for YOUR split. Quote it as 'up to 50 per class (N total)'.")

# %% ---- cell 6.3 ----
# [Cell 6.3]  → answers: R1-4, R1-9, R2-2
# >>> SATISFIES: R2-2 (supervised, target-trained baselines next to zero-shot), R1-4 (seeded few-shot draws, separate from the evaluation set),
#                R1-9 (head-only vs all-layers fine-tuning implemented correctly – the notebook's 'full' branch froze the wrong model)
AGG = np.zeros((NC, 8), np.float32)
for i, c in enumerate(CLASSES): AGG[i, MACRO_MAP[i]] = 1.0                                  # fine-class prob -> macro prob

def set_trainable(model, mode):
    dense = [l for l in model.layers if isinstance(l, L.Dense)][-2:]                        # Dense(128) + softmax head
    for l in model.layers:
        l.trainable = (mode == "all") or (mode == "head" and l in dense) or \
                      (mode == "top" and (l in dense or isinstance(l, L.Bidirectional)))

def make_target_model(space):
    base = load_saved_model()
    if space == "macro":                                                                     # 34-way softmax -> 8 macro probabilities
        out = L.Lambda(lambda p: tf.matmul(p, tf.constant(AGG)), name="macro_agg")(base.output)
        return tf.keras.Model(base.input, out)
    return base

def predict_target(model, X, space, already_macro=None):
    P = model.predict(X[..., None], batch_size=2048, verbose=0)
    if space == "macro" and P.shape[1] == NC: P = P @ AGG
    return P

def eval_target(P, t, idx=None, restrict=False):
    """acc / macro-F1 over classes PRESENT in the target / 8-category macro-F1 / MCC (R2-4, R2-5)."""
    idx = t["eval"] if idx is None else idx; y = t["y"][idx]; P = P.copy()
    if restrict: m = np.zeros(P.shape[1], bool); m[np.unique(t["y"])] = True; P[:, ~m] = -1
    yp = P.argmax(1); present = np.unique(y)
    out = dict(acc=accuracy_score(y, yp), macro_f1=f1_score(y, yp, labels=present, average="macro", zero_division=0), mcc=matthews_corrcoef(y, yp),
               n_eval=len(y), n_classes_present=len(present))
    if t["space"] == "fine":
        out["macro8_f1"] = f1_score(MACRO_MAP[y], MACRO_MAP[yp], average="macro", zero_division=0)
    else:
        out["macro8_f1"] = out["macro_f1"]
    return {k: float(v) for k, v in out.items()}, yp

def draw_k_shot(t, K, seed):
    """K samples per supported class from the POOL only (never from the evaluation set)."""
    rng = np.random.RandomState(seed); sel = []
    for c in np.unique(t["y"][t["pool"]]):
        ids = t["pool"][t["y"][t["pool"]] == c]; sel.extend(rng.choice(ids, min(K, len(ids)), replace=False))
    sel = np.array(sel); assert_disjoint(fewshot=sel, eval=t["eval"]); return sel

def finetune(t, idx, mode, seed, X=None, epochs=15, lr=1e-4, scratch=False, init_masked=None):
    """mode in {'head','top','all'}; scratch=True trains the same architecture from random init on the same samples (target-trained baseline)."""
    set_seed(seed); tf.keras.backend.clear_session(); X = t["X0"] if X is None else X
    model = build_model() if scratch else make_target_model(t["space"])
    if scratch and t["space"] == "macro":
        out = L.Lambda(lambda p: tf.matmul(p, tf.constant(AGG)))(model.output); model = tf.keras.Model(model.input, out)
    if not scratch: set_trainable(model, mode)
    model.compile(tf.keras.optimizers.Adam(1e-3 if scratch else lr), loss=tf.keras.losses.SparseCategoricalCrossentropy() if t["space"] == "macro" else SparseFocalLoss(GAMMA, ALPHA, NC))
    model.fit(X[idx][..., None], t["y"][idx], epochs=epochs, batch_size=min(256, len(idx)), verbose=0)
    return model
print("transfer helpers ready")

# %% ---- cell 6.4 ----
# [Cell 6.4]  → answers: R1-9, R2-2, R2-3, R2-5
# >>> SATISFIES: R2-2 (zero-shot vs few-shot vs full supervised vs target-trained baseline, Table N3), R1-9 / R2-5 (target-trained from scratch separates
#                'model limitation' from 'feature/label shift'), R2-3 (3 draws/seeds with CI)
SEEDS_E6 = SEEDS_RUN; rows = []; FT_EP = 5 if PROFILE == "FAST" else 15
for tn, t in TARGETS.items():
    # --- zero-shot (no training) ---
    P0 = predict_target(make_target_model(t["space"]), t["X0"][t["eval"]], t["space"])
    for restrict in [False, True]:
        m, _ = eval_target(P0, t, restrict=restrict); rows.append(dict(target=tn, regime="zero-shot" + (" (output restricted to supported classes)" if restrict else ""), seed=-1, n_train=0, **m))
    # --- few-shot K=50: head-only / all layers ---
    for seed in SEEDS_E6:
        sel = draw_k_shot(t, 50, seed)
        for mode in ["head", "all"]:
            mdl = finetune(t, sel, mode, seed); m, _ = eval_target(predict_target(mdl, t["X0"][t["eval"]], t["space"]), t)
            rows.append(dict(target=tn, regime=f"few-shot K=50, {mode}", seed=seed, n_train=len(sel), **m))
        mdl = finetune(t, sel, "all", seed, scratch=True); m, _ = eval_target(predict_target(mdl, t["X0"][t["eval"]], t["space"]), t)
        rows.append(dict(target=tn, regime="from scratch on the same K=50 samples", seed=seed, n_train=len(sel), **m))
        # --- full 10 % pool: head-only / all layers / scratch (target-trained baseline) ---
        for mode, scr in [("head", False), ("all", False), ("all", True)]:
            mdl = finetune(t, t["pool"], mode, seed, scratch=scr, epochs=FT_EP); m, _ = eval_target(predict_target(mdl, t["X0"][t["eval"]], t["space"]), t)
            rows.append(dict(target=tn, regime=("from scratch on 10 % pool" if scr else f"full 10 % pool, {mode}"), seed=seed, n_train=len(t["pool"]), **m))
        # --- XGBoost on the 10 % pool (strong non-neural target-trained baseline) ---
        yy = t["y"][t["pool"]]; cl = np.unique(yy); mp = {c: i for i, c in enumerate(cl)}
        xg = xgb.XGBClassifier(n_estimators=300, max_depth=8, learning_rate=0.1, tree_method="hist", device="cuda" if gpus else "cpu", random_state=seed)
        xg.fit(t["X0"][t["pool"]], np.array([mp[v] for v in yy])); pr = xg.predict_proba(t["X0"][t["eval"]])
        Pfull = np.full((len(pr), NC if t["space"] == "fine" else 8), -1.0, np.float32); Pfull[:, cl] = pr
        m, _ = eval_target(Pfull, t); rows.append(dict(target=tn, regime="XGBoost on 10 % pool", seed=seed, n_train=len(t["pool"]), **m))
N3 = pd.DataFrame(rows); N3.to_csv(f"{WORK}/tables/N3_transfer_raw.csv", index=False)
agg = N3.groupby(["target", "regime"]).agg(n_train=("n_train", "first"), acc=("acc", "mean"), macro_f1=("macro_f1", "mean"), macro8_f1=("macro8_f1", "mean"), mcc=("mcc", "mean"),
                                           macro_f1_sd=("macro_f1", "std"), n_runs=("seed", "count")).reset_index()
agg.to_csv(f"{WORK}/tables/N3_transfer_summary.csv", index=False); print(agg.round(4).to_string(index=False))

# %% ---- cell 6.5 ----
# [Cell 6.5]  → answers: R1-4, R2-2, R2-3
# >>> SATISFIES: R1-4 (sample-count sweep K ∈ {5,10,25,50,100}, 5 draws), R2-2 (how fast does the model adapt?), R2-3 (CIs over draws)
rows = []
for tn, t in TARGETS.items():
    for K in [5, 10, 25, 50, 100]:
        for draw in range(2 if PROFILE == "FAST" else 5):
            sel = draw_k_shot(t, K, 1000 + draw)
            for mode in ["head", "all"]:
                mdl = finetune(t, sel, mode, 1000 + draw); m, _ = eval_target(predict_target(mdl, t["X0"][t["eval"]], t["space"]), t)
                rows.append(dict(target=tn, K=K, draw=draw, mode=mode, n_train=len(sel), **m))
sweep = pd.DataFrame(rows); sweep.to_csv(f"{WORK}/tables/S10_fewshot_sweep_raw.csv", index=False)
sw = sweep.groupby(["target", "mode", "K"]).agg(n_train=("n_train", "mean"), acc=("acc", "mean"), macro_f1_mean=("macro_f1", "mean"), macro_f1_sd=("macro_f1", "std"), mcc=("mcc", "mean")).reset_index()
sw.to_csv(f"{WORK}/tables/S10_fewshot_sweep.csv", index=False); print(sw.round(4).to_string(index=False))

# %% ---- cell 6.6 ----
# [Cell 6.6]  → answers: R1-9, R2-5
# >>> SATISFIES: R1-9 (feature sets: all mapped / direct-only / direct+approximated; fill strategies: zero-before-scaling, source-median, train-time masking),
#                R2-5 (does the transfer gap come from approximated or missing features?)
rows = []
for tn, t in TARGETS.items():
    fq = t["feat_quality"]
    FSETS = {"all (direct+approx+filled)": np.ones(ND, bool), "direct only": fq == "direct", "direct + approximated": np.isin(fq, ["direct", "approximated"])}
    for fill in ["zero_raw", "median_raw"]:
        Xf = finalize(t["raw"], fill)
        for fs, keepcols in FSETS.items():
            Xm = Xf.copy(); Xm[:, ~keepcols] = 0.0                                          # 0 in the quantile-normal space = source median (neutral)
            P0 = predict_target(make_target_model(t["space"]), Xm[t["eval"]], t["space"]); m0, _ = eval_target(P0, t)
            rows.append(dict(target=tn, fill=fill, feature_set=fs, n_features=int(keepcols.sum()), regime="zero-shot", **m0))
            sel = draw_k_shot(t, 50, 42); mdl = finetune(t, sel, "all", 42, X=Xm); m1, _ = eval_target(predict_target(mdl, Xm[t["eval"]], t["space"]), t)
            rows.append(dict(target=tn, fill=fill, feature_set=fs, n_features=int(keepcols.sum()), regime="few-shot K=50 (all layers)", **m1))
    # (train-time masking needs a full re-training of the source model -> NOT run in the FAST profile; listed as a limitation)
FS = pd.DataFrame(rows); FS.to_csv(f"{WORK}/tables/S10_featureset_fill.csv", index=False); print(FS[["target", "fill", "feature_set", "regime", "acc", "macro_f1", "macro8_f1", "mcc"]].round(4).to_string(index=False))

# %% ---- cell 6.7 ----
# [Cell 6.7]  → answers: R1-9
# >>> SATISFIES: R1-9 (model shift vs feature shift: per-feature PSI / KS between source test and target evaluation data on DIRECT features)
def psi(a, b, bins=10):
    qs = np.unique(np.quantile(a, np.linspace(0, 1, bins + 1))); qs[0], qs[-1] = -np.inf, np.inf
    pa = np.histogram(a, qs)[0] / len(a) + 1e-6; pb = np.histogram(b, qs)[0] / len(b) + 1e-6
    return float(np.sum((pa - pb) * np.log(pa / pb)))
_, _, Xte_sv = get_scaled("saved"); rs = np.random.RandomState(0); src = Xte_sv[rs.choice(len(Xte_sv), 50000, replace=False)]
for tn, t in TARGETS.items():
    tgt = t["X0"][t["eval"]][rs.choice(len(t["eval"]), min(50000, len(t["eval"])), replace=False)]
    sh = pd.DataFrame(dict(feature=FEATURES, quality=t["feat_quality"], PSI=[psi(src[:, j], tgt[:, j]) for j in range(ND)],
                           KS=[stats.ks_2samp(src[:, j], tgt[:, j]).statistic for j in range(ND)]))
    sh.to_csv(f"{WORK}/tables/S_feature_shift_{tn}.csv", index=False)
    print(f"\n{tn}: median PSI by feature quality (PSI>0.25 = major shift)\n", sh.groupby("quality")[["PSI", "KS"]].median().round(3), "\nworst 8 direct features:\n",
          sh[sh.quality == "direct"].sort_values("PSI", ascending=False).head(8).round(3).to_string(index=False))

# %% ---- cell 6.8 ----
# [Cell 6.8]  → answers: R2-4, R2-5
# >>> SATISFIES: R2-5 (per-class results and results grouped by label-mapping quality), R2-4 (which classes drive the transfer gap)
rows = []
for tn, t in TARGETS.items():
    if t["space"] != "fine": continue                                                        # per-native-label quality is defined for CICIoMT2024
    sel = draw_k_shot(t, 50, 42); mdl = finetune(t, sel, "all", 42)
    for nm, model in [("zero-shot", make_target_model(t["space"])), ("few-shot K=50", mdl)]:
        _, yp = eval_target(predict_target(model, t["X0"][t["eval"]], t["space"]), t); yt = t["y"][t["eval"]]; nat = t["native"][t["eval"]]
        for lab in np.unique(nat):
            mk = nat == lab
            rows.append(dict(target=tn, regime=nm, native_label=lab, mapped_to=IOMT_LABEL_MAP.get(lab), quality=LABEL_QUALITY.get(lab, "?"), n_eval=int(mk.sum()), recall=float((yp[mk] == yt[mk]).mean())))
BYC = pd.DataFrame(rows); BYC.to_csv(f"{WORK}/tables/S_transfer_by_class.csv", index=False)
print(BYC.pivot_table(index=["native_label", "quality", "n_eval"], columns="regime", values="recall").round(3).to_string())
print("\nmean recall by mapping quality:\n", BYC.groupby(["regime", "quality"]).recall.mean().round(3))

# %% [markdown]
# ## 7. E7 – Explainability audit (IG, LIME, KernelSHAP, GradientSHAP) on the SAVED model
# The reference notebook explained ONE flow per class for LIME/IG and 500 random flows for SHAP, with a test-set LIME background and a zero IG baseline.
# This section replaces that with a stratified sample, several baselines, kernel-width sensitivity, repeated runs, faithfulness tests and timing.

# %% ---- cell 7.1 ----
# [Cell 7.1]  → answers: R1-10
# >>> SATISFIES: R1-10 (explicit XAI sample: up to 20 correctly classified + up to 20 misclassified test flows PER CLASS, 34 classes, table published as S7)
import shap
from lime.lime_tabular import LimeTabularExplainer
XM = load_saved_model()
rs = np.random.RandomState(7); rows = []
for c in range(NC):
    ok = np.where((y_te == c) & (yp_saved == c))[0]; bad = np.where((y_te == c) & (yp_saved != c))[0]
    for grp, ids in [("correct", ok), ("misclassified", bad)]:
        for i in (rs.choice(ids, min(10 if PROFILE == "FAST" else 20, len(ids)), replace=False) if len(ids) else []):
            rows.append(dict(test_idx=int(i), true=c, pred=int(yp_saved[i]), group=grp, target_cls=int(yp_saved[i])))     # explain the MODEL's decision
XS = pd.DataFrame(rows); XS.to_csv(f"{WORK}/xai/S7_xai_sample.csv", index=False)
print(XS.groupby("group").size().to_dict(), "| classes with misclassified flows:", XS[XS.group == "misclassified"].true.nunique(), "of", NC)
S7 = XS.assign(cls=[CLASSES[i] for i in XS.true]).pivot_table(index="cls", columns="group", values="test_idx", aggfunc="count", fill_value=0); S7.to_csv(f"{WORK}/tables/S7_xai_sample_counts.csv"); print(S7.T.to_string())
XSX = Xte_saved[XS.test_idx.values]                                   # scaled flows, (n, 46)
# training reference data (NOT test data, unlike the notebook's LIME background)
_, Xs_all, _ = get_scaled("saved"); rs0 = np.random.RandomState(0)
TRAIN_REF = Xs_all[idx_tr][rs0.choice(len(idx_tr), 20000, replace=False)]; del Xs_all; gc.collect()
_ytr_ref = y_all[idx_tr]; BEN_MEAN = saved_scaler.transform(X_raw[idx_tr][_ytr_ref == BEN][:50000]).astype("float32").mean(0)
BASELINES = {"zero": np.zeros(ND, np.float32), "train_mean": TRAIN_REF.mean(0), "benign_mean": BEN_MEAN}
RAND_BASES = TRAIN_REF[rs0.choice(len(TRAIN_REF), 20, replace=False)]

# %% ---- cell 7.2 ----
# [Cell 7.2]  → answers: R1-10, R2-6
# >>> SATISFIES: R1-10 (IG baselines {zero, training mean, benign mean, 20 random training flows} and steps {50,100,300,500}), R2-6 (stability / completeness checks)
@tf.function(reduce_retracing=True)
def _grad_target(x, c):
    with tf.GradientTape() as tape:
        tape.watch(x); p = tf.reduce_sum(XM(x, training=False) * tf.one_hot(c, NC), axis=1)
    return tape.gradient(p, x)

def ig(x, base, cls, steps=50):
    """Integrated gradients (trapezoid rule). Returns attribution (ND,) and completeness gap |sum(attr) - (f(x)-f(base))|."""
    a = np.linspace(0, 1, steps + 1, dtype=np.float32)[:, None]; pts = base[None] + a * (x - base)[None]
    g = _grad_target(tf.constant(pts[..., None]), tf.constant(np.full(len(pts), cls, np.int32))).numpy()[..., 0]
    attr = (x - base) * ((g[:-1] + g[1:]) / 2).mean(0)
    fx, fb = XM(x[None, :, None], training=False).numpy()[0, cls], XM(base[None, :, None], training=False).numpy()[0, cls]
    return attr, abs(attr.sum() - (fx - fb))

def ig_random(x, cls, steps=50):
    res = [ig(x, b, cls, steps)[0] for b in RAND_BASES]; return np.mean(res, 0)

t0 = time.time(); IG0 = np.stack([ig(XSX[i], BASELINES["zero"], XS.target_cls[i], 50)[0] for i in range(len(XS))])
t_ig = (time.time() - t0) / len(XS); print(f"IG(zero, 50 steps) for {len(XS)} flows: {t_ig*1000:.1f} ms / flow"); np.save(f"{WORK}/xai/IG_zero_50.npy", IG0)

# baseline & steps sensitivity on a 100-flow subset
sub = XS.sample(min(60 if PROFILE == "FAST" else 100, len(XS)), random_state=1).index.values
def topk(a, k=5): return set(np.argsort(-np.abs(a))[:k])
def jacc(a, b, k=5): A, B = topk(a, k), topk(b, k); return len(A & B) / len(A | B)
rows = []
for nm, b in BASELINES.items():
    for st in [50, 100, 300, 500]:
        t0 = time.time(); res = [ig(XSX[i], b, XS.target_cls[i], st) for i in sub]; dt = (time.time() - t0) / len(sub)
        A = np.stack([r[0] for r in res]); rows.append(dict(baseline=nm, steps=st, completeness_gap_median=float(np.median([r[1] for r in res])), ms_per_flow=dt * 1000, _A=A))
base_ref = {r["baseline"]: r["_A"] for r in rows if r["steps"] == 500}
for r in rows:                                                          # convergence to the 500-step solution & agreement with the zero baseline
    A = r.pop("_A"); r["top5_jaccard_vs_500steps"] = float(np.mean([jacc(A[j], base_ref[r["baseline"]][j]) for j in range(len(A))]))
    r["top5_jaccard_vs_zero500"] = float(np.mean([jacc(A[j], base_ref["zero"][j]) for j in range(len(A))]))
RA = np.stack([ig_random(XSX[i], XS.target_cls[i]) for i in sub]); rows.append(dict(baseline="20 random training flows", steps=50, top5_jaccard_vs_zero500=float(np.mean([jacc(RA[j], base_ref["zero"][j]) for j in range(len(RA))]))))
S11a = pd.DataFrame(rows); S11a.to_csv(f"{WORK}/tables/S11_ig_baseline_steps.csv", index=False); print(S11a.round(4).to_string(index=False))

# %% ---- cell 7.3 ----
# [Cell 7.3]  → answers: R1-10, R2-6
# >>> SATISFIES: R1-10 (LIME kernel width σ ∈ {0.25,0.5,0.75,1,2}×√D, 10 repeats, R² median/IQR, share ≥0.80 and <0.50, bootstrap CI), R2-6 (LIME stability),
#                R1-10 (training-data background instead of test data)
def make_lime(sigma):
    return LimeTabularExplainer(TRAIN_REF, feature_names=FEATURES, class_names=CLASSES, mode="classification", discretize_continuous=False,
                                kernel_width=sigma * np.sqrt(ND), random_state=0)
pred_fn = lambda z: XM.predict(z[..., None].astype("float32"), batch_size=4096, verbose=0)
def lime_one(expl, x, cls, ns=1000, seed=0):
    expl.random_state = np.random.RandomState(seed)
    e = expl.explain_instance(x, pred_fn, labels=[cls], num_features=ND, num_samples=ns)      # all 46 features -> no selection effect on R²
    w = np.zeros(ND);
    for j, v in e.local_exp[cls]: w[j] = v
    return w, float(e.score[cls] if isinstance(e.score, dict) else e.score)

# main run: default kernel (σ=0.75 ≈ LIME default 0.75*sqrt(D)), 1,000 perturbations, every sampled flow
L_main = make_lime(0.75); t0 = time.time(); res = [lime_one(L_main, XSX[i], XS.target_cls[i]) for i in range(len(XS))]
t_lime = (time.time() - t0) / len(XS); LIME0 = np.stack([r[0] for r in res]); R2 = np.array([r[1] for r in res]); np.save(f"{WORK}/xai/LIME_main.npy", LIME0)
rng = np.random.default_rng(0); bs = [rng.choice(R2, len(R2)).tolist() for _ in range(1000)]
ci = lambda f: (np.percentile([f(np.array(b)) for b in bs], 2.5), np.percentile([f(np.array(b)) for b in bs], 97.5))
s13 = dict(n_flows=len(R2), R2_median=np.median(R2), R2_IQR_lo=np.percentile(R2, 25), R2_IQR_hi=np.percentile(R2, 75), R2_median_CI=ci(np.median),
           share_R2_ge_0_80=(R2 >= 0.8).mean(), share_ge_0_80_CI=ci(lambda a: (a >= 0.8).mean()), share_R2_lt_0_50=(R2 < 0.5).mean(), share_lt_0_50_CI=ci(lambda a: (a < 0.5).mean()), ms_per_flow=t_lime * 1000)
print(json.dumps({k: (list(map(float, v)) if isinstance(v, tuple) else float(v)) for k, v in s13.items()}, indent=1))
pd.Series({k: str(v) for k, v in s13.items()}).to_csv(f"{WORK}/tables/S13_lime_R2_summary.csv")
XS["lime_R2"] = R2; XS.assign(cls=[CLASSES[i] for i in XS.true]).groupby("cls").lime_R2.median().to_csv(f"{WORK}/tables/S13_lime_R2_by_class.csv")

# kernel-width sensitivity with 10 repeats on a 50-flow subset
sub50 = sub[:30 if PROFILE == "FAST" else 50]; N_REP = 3 if PROFILE == "FAST" else 10; rows = []
for sig in [0.25, 0.5, 0.75, 1.0, 2.0]:
    ex = make_lime(sig); W, R = [], []
    for rep in range(N_REP):
        r = [lime_one(ex, XSX[i], XS.target_cls[i], 1000, seed=rep) for i in sub50]; W.append(np.stack([a for a, _ in r])); R.append([b for _, b in r])
    W = np.stack(W); R = np.array(R)                                                                   # (rep, flow, feat)
    stab = np.mean([[jacc(W[a, j], W[b, j]) for a, b in itertools.combinations(range(N_REP), 2)] for j in range(len(sub50))])
    rows.append(dict(sigma_x_sqrtD=sig, R2_median=float(np.median(R)), R2_IQR=f"{np.percentile(R,25):.3f}-{np.percentile(R,75):.3f}", share_R2_ge_0_80=float((R >= 0.8).mean()),
                     share_R2_lt_0_50=float((R < 0.5).mean()), top5_jaccard_across_repeats=float(stab), top5_jaccard_vs_IG=float(np.mean([jacc(W[:, j].mean(0), IG0[sub[j]]) for j in range(len(sub50))]))))
S11b = pd.DataFrame(rows); S11b.to_csv(f"{WORK}/tables/S11_lime_kernel_sensitivity.csv", index=False); print(S11b.round(3).to_string(index=False))

# %% ---- cell 7.4 ----
# [Cell 7.4]  → answers: R1-10, R2-6
# >>> SATISFIES: R1-10 (KernelSHAP + GradientSHAP, not only GradientExplainer on 500 random flows), R2-6 (agreement between methods, timing for offline use)
SHAP_N = 30 if PROFILE == "FAST" else 100; sh_idx = XS.sample(min(SHAP_N, len(XS)), random_state=3).index.values
bg = shap.kmeans(TRAIN_REF, 50)
kexp = shap.KernelExplainer(lambda z: XM.predict(z[..., None].astype("float32"), batch_size=4096, verbose=0), bg)
def _pick(sv, k, cls):
    a = np.asarray(sv if not isinstance(sv, list) else np.stack(sv, -1)); a = np.squeeze(a)
    if a.ndim == 3: a = a[..., cls] if a.shape[-1] == NC else a[cls]                  # tolerate different shap versions
    elif a.ndim == 2 and a.shape[0] == NC: a = a[cls]
    elif a.ndim == 2 and a.shape[-1] == NC: a = a[:, cls]
    return a.reshape(-1)[:ND] if a.ndim == 1 else a[k]
t0 = time.time(); KS = np.stack([_pick(kexp.shap_values(XSX[i][None], nsamples=1000, silent=True), 0, XS.target_cls[i]) for i in sh_idx]); t_ks = (time.time() - t0) / len(sh_idx)
gexp = shap.GradientExplainer(XM, TRAIN_REF[:100][..., None])
t0 = time.time(); GS = np.stack([_pick(gexp.shap_values(XSX[i][None, :, None]), 0, XS.target_cls[i]) for i in sh_idx]); t_gs = (time.time() - t0) / len(sh_idx)
np.save(f"{WORK}/xai/KernelSHAP.npy", KS); np.save(f"{WORK}/xai/GradSHAP.npy", GS)
M = {"IG": IG0[sh_idx], "LIME": LIME0[sh_idx], "KernelSHAP": KS, "GradientSHAP": GS}
rows = []
for a, b in itertools.combinations(M, 2):
    ov = [len(topk(M[a][j]) & topk(M[b][j])) for j in range(len(sh_idx))]; jc = [jacc(M[a][j], M[b][j]) for j in range(len(sh_idx))]
    rho_ = [stats.spearmanr(np.abs(M[a][j]), np.abs(M[b][j]))[0] for j in range(len(sh_idx))]
    rows.append(dict(pair=f"{a} vs {b}", top5_overlap_mean=np.mean(ov), top5_overlap_CI=str(np.percentile(ov, [2.5, 97.5])), top5_jaccard=np.mean(jc), spearman_abs=np.nanmean(rho_)))
AG = pd.DataFrame(rows); AG.to_csv(f"{WORK}/tables/S13_method_agreement.csv", index=False); print(AG.round(3).to_string(index=False))

# %% ---- cell 7.5 ----
# [Cell 7.5]  → answers: R1-10, R2-6
# >>> SATISFIES: R1-10 / R2-6 (are the explanations FAITHFUL? deletion/insertion curves with a random-order control), R2-6 (explanations are an offline analyst tool: timing)
neutral = np.zeros(ND, np.float32)                                                        # 0 in the quantile-normal space = source median
def curve(x, order, cls, mode):
    cur = [x.copy() if mode == "del" else neutral.copy()]
    z = x.copy() if mode == "del" else neutral.copy()
    for j in order:
        z = z.copy(); z[j] = neutral[j] if mode == "del" else x[j]; cur.append(z)
    p = XM.predict(np.stack(cur)[..., None], batch_size=256, verbose=0)[:, cls]; return p
def auc(p): return float((getattr(np, 'trapezoid', None) or np.trapz)(p, dx=1.0 / (len(p) - 1)))
rows = []; rngc = np.random.RandomState(5)
for meth, A in [("IG", IG0[sh_idx]), ("LIME", LIME0[sh_idx]), ("KernelSHAP", KS), ("GradientSHAP", GS)]:
    d, ins = [], []
    for j, i in enumerate(sh_idx):
        x, c = XSX[i], XS.target_cls[i]; o = np.argsort(-np.abs(A[j]))
        d.append(auc(curve(x, o, c, "del"))); ins.append(auc(curve(x, o, c, "ins")))
    rows.append(dict(method=meth, deletion_AUC=np.mean(d), del_CI=str(np.percentile(d, [2.5, 97.5]).round(3)), insertion_AUC=np.mean(ins), ins_CI=str(np.percentile(ins, [2.5, 97.5]).round(3))))
dr, ir = [], []
for i in sh_idx:                                                                          # random-order control (mean of 10 random orders per flow)
    x, c = XSX[i], XS.target_cls[i]; os_ = [rngc.permutation(ND) for _ in range(10)]
    dr.append(np.mean([auc(curve(x, o, c, "del")) for o in os_])); ir.append(np.mean([auc(curve(x, o, c, "ins")) for o in os_]))
rows.append(dict(method="random order (control)", deletion_AUC=np.mean(dr), del_CI=str(np.percentile(dr, [2.5, 97.5]).round(3)), insertion_AUC=np.mean(ir), ins_CI=str(np.percentile(ir, [2.5, 97.5]).round(3))))
FAITH = pd.DataFrame(rows); FAITH.to_csv(f"{WORK}/tables/S13_faithfulness.csv", index=False); print(FAITH.round(3).to_string(index=False))
print("lower deletion-AUC and higher insertion-AUC than the random control = the attribution is faithful to the model.")

TIME = pd.DataFrame([dict(method="forward pass (1 flow)", ms=np.nan), dict(method="IG (50 steps, zero baseline)", ms=t_ig * 1000), dict(method="LIME (1000 perturbations)", ms=t_lime * 1000),
                     dict(method="KernelSHAP (1000 evals, 50-centroid bg)", ms=t_ks * 1000), dict(method="GradientSHAP", ms=t_gs * 1000)])
xb = XSX[:1][..., None]; XM.predict(xb, verbose=0); t0 = time.time(); [XM(xb, training=False).numpy() for _ in range(200)]; TIME.loc[0, "ms"] = (time.time() - t0) / 200 * 1000
TIME.to_csv(f"{WORK}/tables/S13_explanation_timing.csv", index=False); print(TIME.round(2).to_string(index=False))
print("-> Report: explanations are post-hoc, offline analyst tools (hundreds of ms to seconds per flow), NOT part of the inline detection path.")

# %% [markdown]
# ## 8. E8 – Latency and edge-deployment measurements (GPU, CPU 1/2/4 threads, TFLite float32 / int8)

# %% ---- cell 8.1 ----
# [Cell 8.1]  → answers: R1-8, R2-7
# >>> SATISFIES: R1-8 (full latency specification: hardware, batch sizes, synchronous calls, 1,000 warm-up, timed runs, mean/median/p95/p99, preprocessing timed separately),
#                R2-7 (measured – not estimated – inference cost; model size and parameter count)
import psutil
N_WARM = 1000
N_TIMED = {1: 10000, 32: 2000, 256: 1000, 1024: 500}            # timed calls per batch size (bs=1 -> the 10,000 samples quoted in the plan)
XM = load_saved_model()
@tf.function(reduce_retracing=True)
def fwd(x): return XM(x, training=False)
def pct(v): v = np.asarray(v) * 1000; return dict(mean_ms=v.mean(), median_ms=np.median(v), p95_ms=np.percentile(v, 95), p99_ms=np.percentile(v, 99), std_ms=v.std())
rows = []
dev = "GPU" if gpus else "CPU(default)"
for bs in [1, 32, 256, 1024]:
    pool_x = Xte_raw[np.random.RandomState(bs).choice(len(Xte_raw), bs * 50, replace=True)]; pool_s = saved_scaler.transform(pool_x).astype("float32")
    for k in range(N_WARM): fwd(tf.constant(pool_s[(k % 50) * bs:(k % 50 + 1) * bs][..., None])).numpy()                  # warm-up (graph tracing, cuDNN autotune)
    t_model, t_pre, t_e2e = [], [], []
    for k in range(N_TIMED[bs]):
        j = k % 50; raw = pool_x[j * bs:(j + 1) * bs]
        t0 = time.perf_counter(); xs = saved_scaler.transform(raw).astype("float32"); t1 = time.perf_counter()
        _ = fwd(tf.constant(xs[..., None])).numpy(); t2 = time.perf_counter()                                              # .numpy() forces synchronisation
        t_pre.append(t1 - t0); t_model.append(t2 - t1); t_e2e.append(t2 - t0)
    for nm, v in [("model only", t_model), ("preprocessing only", t_pre), ("end-to-end", t_e2e)]:
        r = dict(device=dev, batch=bs, stage=nm, n_timed=len(v), **pct(v)); r["us_per_flow"] = r["median_ms"] * 1000 / bs; r["flows_per_s"] = bs / (r["median_ms"] / 1000); rows.append(r)
LAT = pd.DataFrame(rows); LAT.to_csv(f"{WORK}/tables/S12_latency_gpu.csv", index=False); print(LAT.round(3).to_string(index=False))
print("hardware:", ENV.get("nvidia_smi"), "|", ENV.get("cpu"), "| TF", ENV["tensorflow"], "| params", XM.count_params(), "| model file KB", round(os.path.getsize(f'{ART_DIR}/best_model.keras') / 1024, 1))

# %% ---- cell 8.2 ----
# [Cell 8.2]  → answers: R1-8, R2-7
# >>> SATISFIES: R1-8 / R2-7 (CPU latency with 1, 2, 4 threads – each in a fresh process because TF thread pools cannot be changed after start-up)
cpu_script = f'''
import os, sys, time, json, numpy as np
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
import tensorflow as tf, joblib
th = int(sys.argv[1]); tf.config.threading.set_intra_op_parallelism_threads(th); tf.config.threading.set_inter_op_parallelism_threads(1)
@tf.keras.utils.register_keras_serializable(package="CustomLosses")
class CategoricalFocalLoss(tf.keras.losses.Loss):
    def __init__(self, gamma=2.0, alpha=0.25, name="categorical_focal_loss", **kw): super().__init__(name=name, **kw); self.gamma, self.alpha = gamma, alpha
    def call(self, y_true, y_pred): return y_pred
    def get_config(self): c = super().get_config(); c.update(gamma=self.gamma, alpha=self.alpha); return c
m = tf.keras.models.load_model(r"{ART_DIR}/best_model.keras", compile=False); sc = joblib.load(r"{ART_DIR}/scaler.pkl")
f = tf.function(lambda x: m(x, training=False), reduce_retracing=True)
X = np.load(r"{WORK}/latency/raw_pool.npy"); out = []
for bs, n in [(1, 10000), (32, 2000), (256, 500)]:
    xs = sc.transform(X[:bs * 50]).astype("float32")
    for k in range(min(1000, 200 if bs > 1 else 1000)): f(tf.constant(xs[(k % 50) * bs:(k % 50 + 1) * bs][..., None])).numpy()
    t = []
    for k in range(n):
        j = k % 50; t0 = time.perf_counter(); z = sc.transform(X[j * bs:(j + 1) * bs]).astype("float32"); f(tf.constant(z[..., None])).numpy(); t.append(time.perf_counter() - t0)
    t = np.array(t) * 1000; out.append(dict(threads=th, batch=bs, mean_ms=t.mean(), median_ms=float(np.median(t)), p95_ms=float(np.percentile(t, 95)), p99_ms=float(np.percentile(t, 99)), n_timed=n))
print(json.dumps(out))
'''
np.save(f"{WORK}/latency/raw_pool.npy", Xte_raw[np.random.RandomState(0).choice(len(Xte_raw), 256 * 50, replace=False)])
open(f"{WORK}/latency/bench_cpu.py", "w").write(cpu_script)
rows = []
for th in [1, 2, 4]:
    r = subprocess.run([sys.executable, f"{WORK}/latency/bench_cpu.py", str(th)], capture_output=True, text=True)
    try: rows += json.loads(r.stdout.strip().splitlines()[-1])
    except Exception: print("CPU benchmark failed for", th, "threads:", r.stderr[-500:])
CPU = pd.DataFrame(rows); CPU.to_csv(f"{WORK}/tables/S12_latency_cpu.csv", index=False); print(CPU.round(3).to_string(index=False))

# %% ---- cell 8.3 ----
# [Cell 8.3]  → answers: R1-8, R2-7
# >>> SATISFIES: R2-7 (edge claim: TFLite float32 and int8 – size, latency, and the ACCURACY COST of quantisation), R1-8 (single-flow latency of the deployable artefact)
def to_tflite(quant):
    conv = tf.lite.TFLiteConverter.from_keras_model(XM)
    conv.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS, tf.lite.OpsSet.SELECT_TF_OPS]
    conv._experimental_lower_tensor_list_ops = False
    if quant == "int8":
        conv.optimizations = [tf.lite.Optimize.DEFAULT]
        rep = Xte_saved[np.random.RandomState(0).choice(len(Xte_saved), 500, replace=False)]
        conv.representative_dataset = lambda: ((x[None, :, None].astype("float32"),) for x in rep)
    return conv.convert()
def bench_tflite(blob, th, n_warm=1000, n_time=10000):
    it = tf.lite.Interpreter(model_content=blob, num_threads=th); it.allocate_tensors(); i0, o0 = it.get_input_details()[0], it.get_output_details()[0]
    xs = Xte_saved[:200][..., None].astype("float32")
    for k in range(n_warm): it.set_tensor(i0["index"], xs[k % 200][None]); it.invoke(); it.get_tensor(o0["index"])
    t = []
    for k in range(n_time):
        t0 = time.perf_counter(); it.set_tensor(i0["index"], xs[k % 200][None]); it.invoke(); it.get_tensor(o0["index"]); t.append(time.perf_counter() - t0)
    return pct(t)
def tflite_predict(blob, X, n=3000):
    it = tf.lite.Interpreter(model_content=blob, num_threads=1); it.allocate_tensors(); i0, o0 = it.get_input_details()[0], it.get_output_details()[0]; out = []
    for x in X[:n]: it.set_tensor(i0["index"], x[None, :, None].astype("float32")); it.invoke(); out.append(it.get_tensor(o0["index"])[0])
    return np.array(out)
rows = []; ref_pred = yp_saved[:3000]
for quant in ["float32", "int8"]:
    try:
        blob = to_tflite(quant); open(f"{WORK}/latency/aegis_{quant}.tflite", "wb").write(blob)
        yp_t = tflite_predict(blob, Xte_saved).argmax(1); fm = full_metrics(y_te[:3000], yp_t, NC, MACRO_MAP)
        for th in [1, 4]:
            rows.append(dict(format=f"TFLite {quant}", threads=th, size_KB=len(blob) / 1024, agreement_with_keras=float((yp_t == ref_pred).mean()), acc_first3000=fm["acc"], **bench_tflite(blob, th)))
    except Exception as e:
        rows.append(dict(format=f"TFLite {quant}", error=str(e)[:200])); print("TFLite", quant, "failed:", str(e)[:300], "\n(LSTM conversion needs SELECT_TF_OPS; if it fails, report this limitation honestly and give the Keras CPU numbers.)")
TFL = pd.DataFrame(rows); TFL.to_csv(f"{WORK}/tables/S12_latency_tflite.csv", index=False); print(TFL.round(3).to_string(index=False))

# %% ---- cell 8.4 ----
# [Cell 8.4]  → answers: R1-8, R2-7
# >>> SATISFIES: R2-7 (memory / energy), R1-8 (what was and was NOT measured is stated)
proc = psutil.Process(); rss0 = proc.memory_info().rss
m2 = load_saved_model(); _ = m2.predict(Xte_saved[:1024][..., None], verbose=0); rss1 = proc.memory_info().rss
mem = dict(model_load_plus_first_batch_RSS_MB=(rss1 - rss0) / 2**20, params=int(m2.count_params()), weights_float32_MB=m2.count_params() * 4 / 2**20)
if gpus:
    try:                                                                                      # GPU board power as a proxy during a 1024-batch loop
        pw = []; t_end = time.time() + 10
        while time.time() < t_end:
            fwd(tf.constant(Xte_saved[:1024][..., None])).numpy()
            pw.append(float(subprocess.check_output(["nvidia-smi", "--query-gpu=power.draw", "--format=csv,noheader,nounits"], text=True).split()[0]))
        mem["gpu_power_W_mean_during_load"] = float(np.mean(pw))
    except Exception as e: mem["gpu_power"] = f"n/a ({e})"
mem["edge_board_energy"] = "NOT MEASURED – requires a physical edge board (e.g. Raspberry Pi 4/5, Jetson Nano) with an inline power meter; remove any energy claim from the paper unless measured."
json.dump(mem, open(f"{WORK}/tables/S12_memory_energy.json", "w"), indent=1); print(json.dumps(mem, indent=1))

# %% [markdown]
# ## 9. Release package (Editor: code release, README, seeds, hyper-parameters, weights) and comment-coverage checklist

# %% ---- cell 9.1 ----
# [Cell 9.1]  → answers: ED, R1-11
# >>> SATISFIES: R1-11 + ED (GitHub/Zenodo release: README with run order, seeds, hyper-parameters, split indices, SHA-256, saved weights, requirements), ED (reproducibility statement)
rel = f"{WORK}/release"
for f_ in ["best_model.keras", "scaler.pkl", "label_encoder.pkl", "classification_report.csv", "summary_metrics.csv"]:
    if ART_DIR and os.path.exists(f"{ART_DIR}/{f_}"): shutil.copy(f"{ART_DIR}/{f_}", rel)
try: reqs = subprocess.check_output([sys.executable, "-m", "pip", "freeze"], text=True)
except Exception: reqs = ""
open(f"{rel}/requirements_frozen.txt", "w").write("\n".join(l for l in reqs.splitlines() if l.split("==")[0].lower() in
    {"tensorflow", "keras", "numpy", "pandas", "scikit-learn", "scipy", "imbalanced-learn", "joblib", "xgboost", "lightgbm", "lime", "shap", "psutil", "matplotlib", "seaborn"}))
open(f"{rel}/README.md", "w").write(f"""# AEGIS-Net – code, artifacts and revision experiments
**Paper:** AEGIS-Net (IJIES, Paper ID 20266595).  **Data:** CICIoT2023 (train.csv/test.csv), CICIoMT2024, CIC IoT-DIAD 2024 (links in the paper).
## Contents
- `best_model.keras`, `scaler.pkl`, `label_encoder.pkl` – final model (Quantile + selective SMOTE(T_floor={T_FLOOR}) + focal loss γ={GAMMA}, α={ALPHA}); SHA-256 in `artifact_sha256.json`.
- `split_indices.npz` – exact 64/16 train/validation indices of the 80/20 split of train.csv (shuffle seed {SPLIT_SEED}); test.csv is used unchanged.
- `config.json` – hyper-parameters, seeds {SEEDS}, library versions, hardware.
- `requirements_frozen.txt` – frozen package versions (Python {ENV['python']}, TensorFlow {ENV['tensorflow']}).
## Run order
`AEGIS_Revision_Experiments.ipynb`: section 0 (setup) -> 1 (E1+E2 imported from existing 5-seed runs) -> 2 (final-config reference runs) -> 3 (E3 feature order) -> 4 (E4 saved-model audit, no training) -> 5 (E5 baselines) -> 6 (E6 transfer) -> 7 (E7 XAI) -> 8 (E8 latency).
Each training run is resumable and writes `runs/<tag>__s<seed>.json` plus `preds/<tag>__s<seed>.npz` (labels, predictions, probabilities).
## Determinism
`tf.keras.utils.set_random_seed(seed)` + `tf.config.experimental.enable_op_determinism()`, SMOTE `random_state=seed`, seeds {SEEDS}. GPU results can still differ slightly across hardware/driver versions.
## Reported-result tables
`tables/` contains every CSV that feeds Tables N1–N4 and Supplementary S1–S13 of the revised manuscript.
""")
zp = f"{WORK}/AEGIS_release.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for root in ["release", "tables"]:
        for p in glob.glob(f"{WORK}/{root}/**/*", recursive=True):
            if os.path.isfile(p) and os.path.getsize(p) < 200 * 2**20: z.write(p, os.path.relpath(p, WORK))
print("release package:", zp, f"({os.path.getsize(zp) / 2**20:.1f} MB)")

# %% ---- cell 9.2 ----
# [Cell 9.2]  → answers: ALL
# >>> SATISFIES: ALL comments – final audit: checks that every table promised to the reviewers has actually been produced
CHECK = OrderedDict([
 ("R1-1  factorial / T_floor / gamma",      ["N2_ablation_from_existing_runs.csv", "N2_delta_vs_final.csv"]),
 ("R2-3  multi-seed paired ablation",       ["N2_E2_param_counts.csv"]),
 ("R1-3  feature order / shapes / params",  ["S6_feature_orders.csv", "S9d_feature_order.csv", "S9e_testtime_shuffle_control.csv", "S_layer_shapes_params.csv"]),
 ("R1-2  split / duplicates",               ["S8_split_class_counts.csv", "S8_duplicates_audit.csv", "S8_dedup_scoring.csv"]),
 ("R1-5/6/7 minority, majority, recall",    ["S5_per_class_CI.csv", "S5_confusion_8cat.csv"]),
 ("R2-4  per-class CI / false alerts",      ["S5_per_class_CI.csv", "N1_alert_precision.csv"]),
 ("R1-12/R2-1 baselines",                   ["N4_baselines.csv"]),
 ("R2-2/R1-4/R1-13 transfer regimes",       ["N3_transfer_summary.csv", "S10_fewshot_sweep.csv", "S10_fewshot_counts_CICIoMT2024.csv"]),
 ("R1-9/R2-5 mapping / feature shift",      ["S10_featureset_fill.csv", "S_transfer_by_class.csv", "S1_label_coverage_CICIoMT2024.csv"]),
 ("R1-10/R2-6 XAI",                         ["S7_xai_sample_counts.csv", "S11_ig_baseline_steps.csv", "S11_lime_kernel_sensitivity.csv", "S13_lime_R2_summary.csv", "S13_faithfulness.csv", "S13_method_agreement.csv", "S13_explanation_timing.csv"]),
 ("R1-8/R2-7 latency / edge",               ["S12_latency_gpu.csv", "S12_latency_cpu.csv", "S12_latency_tflite.csv", "S12_memory_energy.json"]),
])
for k, files in CHECK.items():
    st = ["OK " if os.path.exists(f"{WORK}/tables/{f}") else "MISSING" for f in files]
    print(f"{k:42s}", " | ".join(f"{s} {f}" for s, f in zip(st, files)))
print("\nR1-11 / ED release:", "OK" if os.path.exists(f"{WORK}/AEGIS_release.zip") else "MISSING")